/**
 * Payload formats. The transport and server treat payloads as opaque strings labelled with an
 * `encryptionVersion`; only this module and src/crypto know what the labels mean.
 */
import { E2EE_VERSION } from "../crypto/message";

export { E2EE_VERSION };
export const DEV_UNENCRYPTED_VERSION = "dev-unencrypted-v0";

/** True unless the payload is a development test message (readable by anyone, incl. the server). */
export function isEncryptedVersion(version: string): boolean {
  return version !== DEV_UNENCRYPTED_VERSION;
}

/**
 * DEVELOPMENT ONLY — NOT ENCRYPTION. The payload is the text unchanged. Accepted by the server
 * only when ALLOW_UNENCRYPTED_TEST_MESSAGES=true (refused in production). Kept so Phase 3 test
 * messages remain readable and for transport testing.
 */
export const devUnencrypted = {
  version: DEV_UNENCRYPTED_VERSION,
  encode(text: string) {
    return { ciphertext: text, metadata: null };
  },
  decode(payload: { ciphertext: string }) {
    return payload.ciphertext;
  },
};
