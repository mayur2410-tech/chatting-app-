import type { EnvelopeWire } from "../crypto/envelope";
import type { PublicKeySet } from "../crypto/keys";
import { apiRequest } from "./client";

export interface PublicKeyDto extends PublicKeySet {
  createdAt: string;
}

export interface EnvelopeDto extends EnvelopeWire {
  version: number;
  updatedAt: string;
}

export interface MyKeys {
  publicKey: PublicKeyDto | null;
  envelope: EnvelopeDto | null;
}

export interface MemberKeyDto extends PublicKeyDto {
  userId: string;
  active: boolean;
}

export function fetchMyKeys(): Promise<MyKeys> {
  return apiRequest("GET", "/keys/me");
}

export function setupKeys(publicKey: PublicKeySet, envelope: EnvelopeWire): Promise<MyKeys> {
  return apiRequest("POST", "/keys", { publicKey, envelope });
}

export function updateEnvelope(envelope: EnvelopeWire, expectedVersion: number): Promise<MyKeys> {
  return apiRequest("PUT", "/keys/envelope", { envelope, expectedVersion });
}

export function rotateKeys(publicKey: PublicKeySet, envelope: EnvelopeWire, expectedVersion: number): Promise<MyKeys> {
  return apiRequest("POST", "/keys/rotate", { publicKey, envelope, expectedVersion });
}

export async function fetchConversationKeys(conversationId: string): Promise<MemberKeyDto[]> {
  const res = await apiRequest<{ keys: MemberKeyDto[] }>(
    "GET",
    `/conversations/${encodeURIComponent(conversationId)}/keys`,
  );
  return res.keys;
}
