/**
 * Opt-in end-to-end test of duo-e2ee-v1 against a running server (real HTTP, WebSocket, database),
 * using the app's own CryptoSession. Two provisioned throwaway accounts are required:
 *
 *   DUO_E2E_URL=http://127.0.0.1:5173 \
 *   DUO_E2E_A_USER=... DUO_E2E_A_PASSWORD=... DUO_E2E_B_USER=... DUO_E2E_B_PASSWORD=... \
 *   npx vitest run src/e2e
 *
 * The URL's origin must be in the server's ALLOWED_ORIGINS. Skipped when DUO_E2E_URL is unset.
 * Point it only at a disposable test database: it sets up (and rotates) real keys for both users.
 */
import { describe, expect, it } from "vitest";
import { fetchMyKeys } from "../api/keys";
import { EnvelopeError } from "../crypto/envelope";
import { CryptoSession } from "../crypto/session";

const env: Record<string, string | undefined> =
  (globalThis as { process?: { env: Record<string, string | undefined> } }).process?.env ?? {};
const BASE = env.DUO_E2E_URL;

interface Jar {
  userId: string;
  cookie: string;
  csrf: string;
}

// Route the app's relative /api requests to BASE as whichever user is "active".
let active: Jar | null = null;
const realFetch = globalThis.fetch;
if (BASE) {
  globalThis.fetch = (input: RequestInfo | URL, init: RequestInit = {}) => {
    const url = typeof input === "string" && input.startsWith("/") ? BASE + input : input;
    const headers = new Headers(init.headers);
    headers.set("Origin", BASE);
    if (active) {
      headers.set("Cookie", active.cookie);
      if ((init.method ?? "GET") !== "GET") headers.set("X-CSRF-Token", active.csrf);
    }
    return realFetch(url, { ...init, headers });
  };
}

async function as<T>(jar: Jar, fn: () => Promise<T>): Promise<T> {
  const previous = active;
  active = jar;
  try {
    return await fn();
  } finally {
    active = previous;
  }
}

async function login(username: string, password: string): Promise<Jar> {
  const res = await realFetch(`${BASE}/api/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Origin: BASE! },
    body: JSON.stringify({ username, password }),
  });
  expect(res.status).toBe(200);
  const body = (await res.json()) as { user: { id: string }; csrfToken: string };
  const cookie = res.headers.getSetCookie()[0].split(";")[0];
  return { userId: body.user.id, cookie, csrf: body.csrfToken };
}

function openSocket(jar: Jar) {
  const events: Array<Record<string, any>> = [];
  const waiters: Array<() => void> = [];
  const ws = new WebSocket(`${BASE!.replace(/^http/, "ws")}/api/ws/chat`, {
    headers: { Origin: BASE!, Cookie: jar.cookie },
  } as unknown as string[]);
  ws.onmessage = (e) => {
    events.push(JSON.parse(String(e.data)));
    waiters.splice(0).forEach((w) => w());
  };
  const opened = new Promise<void>((resolve, reject) => {
    ws.onopen = () => resolve();
    ws.onerror = () => reject(new Error("socket failed"));
  });
  async function next(type: string, timeoutMs = 5000) {
    const deadline = Date.now() + timeoutMs;
    for (;;) {
      const i = events.findIndex((e) => e.type === type);
      if (i >= 0) return events.splice(i, 1)[0];
      if (Date.now() > deadline) throw new Error(`timed out waiting for ${type}`);
      await new Promise<void>((r) => {
        waiters.push(r);
        setTimeout(r, 100);
      });
    }
  }
  return { ws, opened, next };
}

function randomPassphrase() {
  return `pp-${crypto.randomUUID()}`;
}

describe.skipIf(!BASE)("duo-e2ee-v1 end to end (two users, real server)", () => {
  it("encrypts, delivers, verifies, recovers on a new device, and survives key rotation", async () => {
    const a = await login(env.DUO_E2E_A_USER!, env.DUO_E2E_A_PASSWORD!);
    const b = await login(env.DUO_E2E_B_USER!, env.DUO_E2E_B_PASSWORD!);
    const ppA = randomPassphrase();
    const ppB = randomPassphrase();

    // 1. Both users set up keys (generated locally; only public keys + sealed envelope uploaded).
    const sa = await as(a, () => CryptoSession.setUp(a.userId, ppA));
    const sb = await as(b, () => CryptoSession.setUp(b.userId, ppB));

    const conv = await as(a, async () => {
      const res = await fetch("/api/conversations");
      return ((await res.json()) as { conversations: Array<{ id: string }> }).conversations[0].id;
    });

    // 2. Each fetches and pins the other's key (trust on first use) and sees the same safety code.
    await as(a, () => sa.attach(conv, b.userId));
    await as(b, () => sb.attach(conv, a.userId));
    expect(sa.getSnapshot().kind).toBe("unverified");
    expect(sb.getSnapshot().kind).toBe("unverified");
    expect(sa.getSnapshot().safetyCode).toEqual(sb.getSnapshot().safetyCode);
    expect(sa.getSnapshot().safetyCode).toHaveLength(12);
    await as(a, () => sa.markVerified());
    expect(sa.getSnapshot().kind).toBe("verified");

    // 3. A sends an encrypted message over the real WebSocket; B receives and decrypts it.
    const wa = openSocket(a);
    const wb = openSocket(b);
    await Promise.all([wa.opened, wb.opened]);

    const text = "E2E check 🔐 नमस्ते — 你好";
    const clientMessageId = crypto.randomUUID();
    const payload = await sa.encrypt(text, { conversationId: conv, clientMessageId });
    wa.ws.send(
      JSON.stringify({
        type: "message.send",
        clientMessageId,
        ciphertext: payload.ciphertext,
        encryptionVersion: "duo-e2ee-v1",
        encryptionMetadata: payload.metadata,
      }),
    );
    const ack = await wa.next("message.ack");
    const received = (await wb.next("message.new")).message;
    expect(received.id).toBe(ack.message.id);
    expect(received.ciphertext).not.toContain("E2E check");
    expect(JSON.stringify(received.encryptionMetadata)).not.toContain("E2E check");
    expect(await as(b, () => sb.decrypt(received))).toEqual({ ok: true, text });
    expect(await as(a, () => sa.decrypt(ack.message))).toEqual({ ok: true, text }); // sender's own copy

    // 4. What the server stored is ciphertext only.
    const stored = await as(b, async () => {
      const res = await fetch(`/api/conversations/${conv}/messages`);
      return ((await res.json()) as { messages: Array<{ ciphertext: string }> }).messages;
    });
    expect(stored.some((m) => m.ciphertext.includes("E2E check"))).toBe(false);

    // 5. "New device": unlock A's keys from the server-stored envelope with the passphrase only.
    const envelope = (await as(a, () => fetchMyKeys())).envelope!;
    await expect(CryptoSession.unlock(a.userId, "wrong passphrase!!", envelope)).rejects.toBeInstanceOf(EnvelopeError);
    const sa2 = await CryptoSession.unlock(a.userId, ppA, envelope);
    await as(a, () => sa2.attach(conv, b.userId));
    expect(sa2.getSnapshot().kind).toBe("verified"); // trust decisions travel with the envelope
    expect(await as(a, () => sa2.decrypt(received))).toEqual({ ok: true, text });

    // 6. B rotates keys: A is warned and sending pauses until A accepts the new key.
    await as(b, () => sb.rotateKeys());
    await wa.next("keys.changed");
    await as(a, () => sa.refreshDirectory());
    expect(sa.getSnapshot().kind).toBe("changed");
    await expect(sa.encrypt("blocked", { conversationId: conv, clientMessageId: crypto.randomUUID() })).rejects.toThrow();
    await as(a, () => sa.acceptPartnerKey());
    expect(sa.getSnapshot().kind).toBe("unverified");

    const id2 = crypto.randomUUID();
    const p2 = await sa.encrypt("after rotation", { conversationId: conv, clientMessageId: id2 });
    wa.ws.send(
      JSON.stringify({
        type: "message.send",
        clientMessageId: id2,
        ciphertext: p2.ciphertext,
        encryptionVersion: "duo-e2ee-v1",
        encryptionMetadata: p2.metadata,
      }),
    );
    const second = (await wb.next("message.new")).message;
    expect(await as(b, () => sb.decrypt(second))).toEqual({ ok: true, text: "after rotation" });
    // B's old key is still in its envelope, so the first message stays readable.
    expect(await as(b, () => sb.decrypt(received))).toEqual({ ok: true, text });

    wa.ws.close();
    wb.ws.close();
    [sa, sa2, sb].forEach((s) => s.destroy());
  }, 60_000);
});
