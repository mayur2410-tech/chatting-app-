import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { KeyRound, RefreshCw, ShieldAlert, ShieldCheck, ShieldQuestion, X } from "lucide-react";
import { SessionInvalidError, type CryptoSession, type TrustSnapshot } from "../../crypto/session";
import { MIN_PASSPHRASE_LENGTH } from "../../crypto/useKeyVault";
import { Button, PasswordField } from "../ui";

interface SecuritySheetProps {
  session: CryptoSession;
  trust: TrustSnapshot;
  partnerName: string;
  onClose: () => void;
  /** Called when the session can no longer be used (e.g. passphrase changed elsewhere). */
  onSessionInvalid: () => void;
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="border-t border-stone-200 px-5 py-4 dark:border-stone-800">
      <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-stone-500 dark:text-stone-400">{title}</h3>
      {children}
    </section>
  );
}

const STATUS: Record<TrustSnapshot["kind"], { icon: ReactNode; text: (name: string) => string; tone: string }> = {
  verified: {
    icon: <ShieldCheck className="size-5" aria-hidden="true" />,
    text: (n) => `You've verified ${n}'s safety code. Messages are end-to-end encrypted.`,
    tone: "text-emerald-700 dark:text-emerald-400",
  },
  unverified: {
    icon: <ShieldQuestion className="size-5" aria-hidden="true" />,
    text: (n) => `Messages are end-to-end encrypted, but you haven't verified ${n}'s safety code yet.`,
    tone: "text-stone-700 dark:text-stone-300",
  },
  changed: {
    icon: <ShieldAlert className="size-5" aria-hidden="true" />,
    text: (n) =>
      `${n}'s security key has changed. This happens if they reset or rotated their keys — or if someone is interfering. Compare the new safety code before continuing.`,
    tone: "text-amber-700 dark:text-amber-400",
  },
  "partner-not-set-up": {
    icon: <ShieldQuestion className="size-5" aria-hidden="true" />,
    text: (n) => `${n} hasn't set up encryption yet. You can send messages once they have.`,
    tone: "text-stone-700 dark:text-stone-300",
  },
  "no-conversation": {
    icon: <ShieldQuestion className="size-5" aria-hidden="true" />,
    text: () => "The conversation isn't ready yet.",
    tone: "text-stone-700 dark:text-stone-300",
  },
};

export function SecuritySheet({ session, trust, partnerName, onClose, onSessionInvalid }: SecuritySheetProps) {
  const [busy, setBusy] = useState<string | null>(null);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [showPassphrase, setShowPassphrase] = useState(false);
  const [confirmRotate, setConfirmRotate] = useState(false);
  const [newPass, setNewPass] = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const closeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    closeRef.current?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  async function run(label: string, action: () => Promise<void>, success: string) {
    setBusy(label);
    setMessage(null);
    try {
      await action();
      setMessage({ ok: true, text: success });
    } catch (err) {
      if (err instanceof SessionInvalidError) {
        onSessionInvalid();
        return;
      }
      setMessage({ ok: false, text: "That didn't work. Check your connection and try again." });
    } finally {
      setBusy(null);
    }
  }

  async function changePassphrase(e: FormEvent) {
    e.preventDefault();
    if (newPass.length < MIN_PASSPHRASE_LENGTH) {
      setMessage({ ok: false, text: `Use at least ${MIN_PASSPHRASE_LENGTH} characters.` });
      return;
    }
    if (newPass !== confirmPass) {
      setMessage({ ok: false, text: "The passphrases don't match." });
      return;
    }
    const value = newPass;
    setNewPass("");
    setConfirmPass("");
    await run("passphrase", () => session.changePassphrase(value), "Passphrase changed. Use the new one to unlock from now on.");
    setShowPassphrase(false);
  }

  const status = STATUS[trust.kind];

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 sm:items-center" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="security-title"
        className="animate-fade-up safe-bottom max-h-[90dvh] w-full max-w-md overflow-y-auto rounded-t-2xl bg-stone-50 shadow-xl sm:rounded-2xl dark:bg-stone-900"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="flex items-center justify-between px-5 pb-3 pt-4">
          <h2 id="security-title" className="text-base font-semibold">
            Encryption
          </h2>
          <button
            ref={closeRef}
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="inline-flex size-9 items-center justify-center rounded-full text-stone-500 hover:bg-stone-200/70 dark:hover:bg-stone-800"
          >
            <X className="size-5" />
          </button>
        </header>

        <div className={`flex gap-2.5 px-5 pb-4 text-sm ${status.tone}`}>
          <span className="mt-0.5 shrink-0">{status.icon}</span>
          <p>{status.text(partnerName)}</p>
        </div>

        {trust.safetyCode && (
          <Section title="Safety code">
            <p className="mb-3 text-sm text-stone-600 dark:text-stone-400">
              Compare these numbers with {partnerName}'s screen, in person or on a call. If they match, nobody — not even
              the server — can read or fake your messages.
            </p>
            <div
              className="grid grid-cols-4 gap-x-3 gap-y-1.5 rounded-xl bg-white px-4 py-3 text-center font-mono text-[15px] tracking-wider text-stone-800 dark:bg-stone-950 dark:text-stone-200"
              aria-label={`Safety code: ${trust.safetyCode.join(" ")}`}
            >
              {trust.safetyCode.map((group, i) => (
                <span key={i}>{group}</span>
              ))}
            </div>
            <div className="mt-3">
              {trust.kind === "unverified" && (
                <Button
                  onClick={() => run("verify", () => session.markVerified(), "Marked as verified.")}
                  loading={busy === "verify"}
                >
                  <ShieldCheck className="size-4" aria-hidden="true" />
                  The codes match — mark as verified
                </Button>
              )}
              {trust.kind === "changed" && (
                <div className="space-y-2">
                  <Button
                    onClick={() => run("verify", () => session.markVerified(), "New key verified.")}
                    loading={busy === "verify"}
                  >
                    <ShieldCheck className="size-4" aria-hidden="true" />
                    The codes match — trust the new key
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() =>
                      run("accept", () => session.acceptPartnerKey(), "New key accepted (not verified). Compare codes soon.")
                    }
                    loading={busy === "accept"}
                  >
                    Accept without verifying
                  </Button>
                </div>
              )}
              {trust.kind === "verified" && (
                <p className="flex items-center gap-1.5 text-sm font-medium text-emerald-700 dark:text-emerald-400">
                  <ShieldCheck className="size-4" aria-hidden="true" /> Verified
                </p>
              )}
            </div>
          </Section>
        )}

        <Section title="Your keys">
          <p className="mb-3 font-mono text-xs text-stone-500 dark:text-stone-400">Key ID {trust.myKeyId.match(/.{1,4}/g)?.join(" ")}</p>

          {showPassphrase ? (
            <form onSubmit={changePassphrase} className="space-y-3" noValidate>
              <PasswordField
                id="change-pass"
                label="New passphrase"
                autoComplete="new-password"
                value={newPass}
                onChange={(e) => setNewPass(e.target.value)}
                maxLength={256}
              />
              <PasswordField
                id="change-pass-confirm"
                label="Repeat new passphrase"
                autoComplete="new-password"
                value={confirmPass}
                onChange={(e) => setConfirmPass(e.target.value)}
                maxLength={256}
              />
              <div className="flex gap-2">
                <Button type="button" variant="ghost" onClick={() => setShowPassphrase(false)}>
                  Cancel
                </Button>
                <Button type="submit" loading={busy === "passphrase"}>
                  Save
                </Button>
              </div>
            </form>
          ) : confirmRotate ? (
            <div className="space-y-2">
              <p className="text-sm text-stone-600 dark:text-stone-400">
                Rotating creates new keys. {partnerName} will see that your safety code changed and should compare it again.
                Older messages stay readable.
              </p>
              <div className="flex gap-2">
                <Button variant="ghost" onClick={() => setConfirmRotate(false)}>
                  Cancel
                </Button>
                <Button
                  onClick={async () => {
                    await run("rotate", () => session.rotateKeys(), "New keys created.");
                    setConfirmRotate(false);
                  }}
                  loading={busy === "rotate"}
                >
                  Rotate keys
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-1">
              <Button variant="ghost" onClick={() => setShowPassphrase(true)} className="justify-start px-3">
                <KeyRound className="size-4" aria-hidden="true" />
                Change passphrase
              </Button>
              <Button variant="ghost" onClick={() => setConfirmRotate(true)} className="justify-start px-3">
                <RefreshCw className="size-4" aria-hidden="true" />
                Rotate my keys
              </Button>
            </div>
          )}

          <div className="mt-2 min-h-5" aria-live="polite">
            {message && (
              <p className={`text-sm ${message.ok ? "text-emerald-700 dark:text-emerald-400" : "text-red-600 dark:text-red-400"}`}>
                {message.text}
              </p>
            )}
          </div>
        </Section>
      </div>
    </div>
  );
}
