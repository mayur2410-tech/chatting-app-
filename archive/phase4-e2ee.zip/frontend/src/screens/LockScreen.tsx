import { useEffect, useRef, useState, type FormEvent } from "react";
import { Lock } from "lucide-react";
import { AuthLayout } from "../components/AuthLayout";
import { Button, PasswordField } from "../components/ui";

interface LockScreenProps {
  username: string;
  /** Unlocks the encryption keys locally. Resolves to an error message, or null on success. */
  onUnlock: (passphrase: string) => Promise<string | null>;
  onSignOut: () => void;
}

/**
 * The passphrase decrypts this user's key envelope on the device (PBKDF2 → AES-GCM).
 * It is never sent to the server; a wrong passphrase simply fails to decrypt.
 */
export function LockScreen({ username, onUnlock, onSignOut }: LockScreenProps) {
  const [passphrase, setPassphrase] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setError(null);
    if (!passphrase) {
      setError("Enter your passphrase.");
      return;
    }
    setBusy(true);
    const submitted = passphrase;
    setPassphrase("");
    const message = await onUnlock(submitted);
    setBusy(false);
    if (message) {
      setError(message);
      inputRef.current?.focus();
    }
  }

  return (
    <AuthLayout
      title="Locked"
      subtitle={`Signed in as ${username}`}
      note="Forgot your passphrase? An administrator can reset your keys, but existing messages can't be recovered."
      icon={
        <div className="flex size-14 items-center justify-center rounded-2xl bg-stone-200 dark:bg-stone-800">
          <Lock className="size-6 text-stone-600 dark:text-stone-300" aria-hidden="true" />
        </div>
      }
      footer={
        <button
          type="button"
          onClick={onSignOut}
          className="text-sm text-stone-500 underline-offset-4 hover:underline dark:text-stone-400"
        >
          Sign out
        </button>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <PasswordField
          ref={inputRef}
          id="passphrase"
          label="Passphrase"
          autoComplete="off"
          value={passphrase}
          onChange={(e) => setPassphrase(e.target.value)}
          maxLength={256}
        />
        <div className="min-h-5" aria-live="polite">
          {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
        </div>
        <Button type="submit" loading={busy}>
          {busy ? "Unlocking…" : "Unlock"}
        </Button>
      </form>
    </AuthLayout>
  );
}
