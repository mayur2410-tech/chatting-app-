import { useState, type FormEvent } from "react";
import { KeyRound } from "lucide-react";
import { AuthLayout } from "../components/AuthLayout";
import { Button, PasswordField } from "../components/ui";
import { MIN_PASSPHRASE_LENGTH } from "../crypto/useKeyVault";

interface SetupScreenProps {
  displayName: string;
  /** Resolves to an error message, or null on success. */
  onSetUp: (passphrase: string) => Promise<string | null>;
  onSignOut: () => void;
}

/**
 * First-time encryption setup. Keys are generated on this device; the passphrase encrypts them
 * before anything is uploaded and is never sent to the server.
 */
export function SetupScreen({ displayName, onSetUp, onSignOut }: SetupScreenProps) {
  const [passphrase, setPassphrase] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (busy) return;
    setError(null);
    if (passphrase.length < MIN_PASSPHRASE_LENGTH) {
      setError(`Use at least ${MIN_PASSPHRASE_LENGTH} characters. A few unrelated words works well.`);
      return;
    }
    if (passphrase !== confirm) {
      setError("The passphrases don't match.");
      return;
    }
    setBusy(true);
    const message = await onSetUp(passphrase);
    setBusy(false);
    if (message) setError(message);
    else {
      setPassphrase("");
      setConfirm("");
    }
  }

  return (
    <AuthLayout
      title="Set up encryption"
      subtitle={`Signed in as ${displayName}`}
      icon={
        <div className="flex size-14 items-center justify-center rounded-2xl bg-stone-200 dark:bg-stone-800">
          <KeyRound className="size-6 text-stone-600 dark:text-stone-300" aria-hidden="true" />
        </div>
      }
      footer={
        <button
          type="button"
          onClick={onSignOut}
          className="text-sm text-stone-500 underline-offset-4 hover:underline dark:text-stone-400"
        >
          Sign out
        </button>
      }
    >
      <div className="mb-5 space-y-2 rounded-xl bg-stone-200/60 px-4 py-3 text-sm text-stone-600 dark:bg-stone-800/60 dark:text-stone-300">
        <p>Choose a passphrase to protect your encryption keys. It's used on this device and never sent to the server.</p>
        <p className="font-medium">If you forget it, your messages can't be recovered.</p>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        <PasswordField
          id="new-passphrase"
          label="Passphrase"
          autoComplete="new-password"
          value={passphrase}
          onChange={(e) => setPassphrase(e.target.value)}
          maxLength={256}
        />
        <PasswordField
          id="confirm-passphrase"
          label="Repeat passphrase"
          autoComplete="new-password"
          value={confirm}
          onChange={(e) => setConfirm(e.target.value)}
          maxLength={256}
        />
        <div className="min-h-5" aria-live="polite">
          {error && <p className="text-sm text-red-600 dark:text-red-400">{error}</p>}
        </div>
        <Button type="submit" loading={busy}>
          {busy ? "Creating keys…" : "Create keys"}
        </Button>
      </form>
    </AuthLayout>
  );
}
