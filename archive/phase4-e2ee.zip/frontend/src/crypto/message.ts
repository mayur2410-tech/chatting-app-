/**
 * duo-e2ee-v1 message encryption. See docs/e2ee-design.md.
 *
 *   content key K   ← 32 random bytes
 *   ciphertext      ← AES-256-GCM(K, iv, text, AAD)
 *   per recipient R ← ECDH(ephemeral, R.encryptionPublic) → HKDF-SHA256(salt, info=R.keyId) → KEK
 *                     wrappedKey = AES-256-GCM(KEK, iv_R, K, AAD)
 *   sig             ← ECDSA-P256-SHA256(sender.signingPrivate, canonical(all fields + context))
 *
 * AAD binds every encryption to (version, conversationId, senderId, senderKeyId, clientMessageId),
 * so payloads cannot be moved between messages, senders or conversations.
 */
import { fromB64url, fromUtf8, randomBytes, toB64url, utf8, wipe } from "./encoding";
import { ECDH_PARAMS, ECDSA_PARAMS, type OwnKey, type PeerKey } from "./keys";

export const E2EE_VERSION = "duo-e2ee-v1";

export interface MessageContext {
  conversationId: string;
  senderId: string;
  clientMessageId: string;
}

export interface WrapEntry {
  recipientKeyId: string;
  iv: string;
  wrappedKey: string;
}

export interface E2eeMetadata {
  v: 1;
  senderKeyId: string;
  iv: string;
  ephemeralPublicKey: string;
  salt: string;
  wraps: WrapEntry[];
  sig: string;
}

export interface EncryptedPayload {
  ciphertext: string;
  metadata: E2eeMetadata;
}

export type DecryptFailure = "malformed" | "unknown_sender_key" | "bad_signature" | "not_for_this_key" | "corrupt";

export class DecryptError extends Error {
  constructor(readonly reason: DecryptFailure) {
    super(reason);
    this.name = "DecryptError";
  }
}

/** Anything that can receive the content key: the partner's and the sender's own public keys. */
export interface Recipient {
  keyId: string;
  encryptionPublic: CryptoKey;
}

const ECDSA_SIGN = { name: "ECDSA", hash: "SHA-256" } as const;

function associatedData(ctx: MessageContext, senderKeyId: string): Uint8Array {
  return utf8(JSON.stringify([E2EE_VERSION, ctx.conversationId, ctx.senderId, senderKeyId, ctx.clientMessageId]));
}

function signedBytes(ctx: MessageContext, ciphertext: string, m: Omit<E2eeMetadata, "sig">): Uint8Array {
  // Fixed-order JSON array → deterministic, unambiguous byte string.
  return utf8(
    JSON.stringify([
      E2EE_VERSION,
      ctx.conversationId,
      ctx.senderId,
      m.senderKeyId,
      ctx.clientMessageId,
      m.v,
      m.iv,
      ciphertext,
      m.ephemeralPublicKey,
      m.salt,
      m.wraps.map((w) => [w.recipientKeyId, w.iv, w.wrappedKey]),
    ]),
  );
}

async function wrappingKey(
  sharedSecret: ArrayBuffer,
  salt: Uint8Array,
  recipientKeyId: string,
  usage: "encrypt" | "decrypt",
): Promise<CryptoKey> {
  const ikm = await crypto.subtle.importKey("raw", sharedSecret, "HKDF", false, ["deriveKey"]);
  return crypto.subtle.deriveKey(
    { name: "HKDF", hash: "SHA-256", salt, info: utf8(`${E2EE_VERSION}/wrap\0${recipientKeyId}`) },
    ikm,
    { name: "AES-GCM", length: 256 },
    false,
    [usage],
  );
}

export async function encryptMessage(
  text: string,
  ctx: MessageContext,
  sender: OwnKey,
  recipients: Recipient[],
): Promise<EncryptedPayload> {
  const unique = [...new Map(recipients.map((r) => [r.keyId, r])).values()];
  if (unique.length === 0) throw new Error("No recipients");

  const aad = associatedData(ctx, sender.keyId);
  const contentKeyBytes = randomBytes(32);
  const plaintext = utf8(text);
  try {
    const contentKey = await crypto.subtle.importKey("raw", contentKeyBytes, "AES-GCM", false, ["encrypt"]);
    const iv = randomBytes(12);
    const ciphertext = toB64url(
      await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: aad }, contentKey, plaintext),
    );

    const ephemeral = (await crypto.subtle.generateKey(ECDH_PARAMS, false, ["deriveBits"])) as CryptoKeyPair;
    const ephemeralPublicKey = toB64url(await crypto.subtle.exportKey("spki", ephemeral.publicKey));
    const salt = randomBytes(32);

    const wraps: WrapEntry[] = [];
    for (const r of unique) {
      const shared = await crypto.subtle.deriveBits({ name: "ECDH", public: r.encryptionPublic }, ephemeral.privateKey, 256);
      const kek = await wrappingKey(shared, salt, r.keyId, "encrypt");
      const wrapIv = randomBytes(12);
      const wrapped = await crypto.subtle.encrypt({ name: "AES-GCM", iv: wrapIv, additionalData: aad }, kek, contentKeyBytes);
      wraps.push({ recipientKeyId: r.keyId, iv: toB64url(wrapIv), wrappedKey: toB64url(wrapped) });
    }

    const unsigned = { v: 1 as const, senderKeyId: sender.keyId, iv: toB64url(iv), ephemeralPublicKey, salt: toB64url(salt), wraps };
    const sig = await crypto.subtle.sign(ECDSA_SIGN, sender.signingPrivate, signedBytes(ctx, ciphertext, unsigned));
    return { ciphertext, metadata: { ...unsigned, sig: toB64url(sig) } };
  } finally {
    wipe(contentKeyBytes);
    wipe(plaintext);
  }
}

function parseMetadata(raw: unknown): E2eeMetadata {
  const m = raw as Partial<E2eeMetadata> | null;
  const isStr = (x: unknown): x is string => typeof x === "string" && x.length > 0 && x.length < 4096;
  if (
    !m ||
    m.v !== 1 ||
    !isStr(m.senderKeyId) ||
    !isStr(m.iv) ||
    !isStr(m.ephemeralPublicKey) ||
    !isStr(m.salt) ||
    !isStr(m.sig) ||
    !Array.isArray(m.wraps) ||
    m.wraps.length === 0 ||
    !m.wraps.every((w) => w && isStr(w.recipientKeyId) && isStr(w.iv) && isStr(w.wrappedKey))
  ) {
    throw new DecryptError("malformed");
  }
  return m as E2eeMetadata;
}

export function senderKeyIdOf(metadata: unknown): string {
  return parseMetadata(metadata).senderKeyId;
}

/**
 * Verifies the signature first, then decrypts. `senderKey` must be the published key whose id is
 * metadata.senderKeyId *and* whose owner is ctx.senderId — the caller looks it up and checks that.
 */
export async function decryptMessage(
  payload: { ciphertext: string; encryptionMetadata: unknown },
  ctx: MessageContext,
  senderKey: Pick<PeerKey, "keyId" | "signingPublic">,
  myKeys: Pick<OwnKey, "keyId" | "encryptionPrivate">[],
): Promise<string> {
  const m = parseMetadata(payload.encryptionMetadata);
  if (senderKey.keyId !== m.senderKeyId) throw new DecryptError("unknown_sender_key");

  let valid = false;
  try {
    const { sig, ...unsigned } = m;
    valid = await crypto.subtle.verify(
      ECDSA_SIGN,
      senderKey.signingPublic,
      fromB64url(sig),
      signedBytes(ctx, payload.ciphertext, unsigned),
    );
  } catch {
    valid = false;
  }
  if (!valid) throw new DecryptError("bad_signature");

  const mine = myKeys.find((k) => m.wraps.some((w) => w.recipientKeyId === k.keyId));
  const wrap = mine && m.wraps.find((w) => w.recipientKeyId === mine.keyId);
  if (!mine || !wrap) throw new DecryptError("not_for_this_key");

  const aad = associatedData(ctx, m.senderKeyId);
  let contentKeyBytes: Uint8Array | null = null;
  try {
    const ephemeral = await crypto.subtle.importKey("spki", fromB64url(m.ephemeralPublicKey), ECDH_PARAMS, false, []);
    const shared = await crypto.subtle.deriveBits({ name: "ECDH", public: ephemeral }, mine.encryptionPrivate, 256);
    const kek = await wrappingKey(shared, fromB64url(m.salt), mine.keyId, "decrypt");
    contentKeyBytes = new Uint8Array(
      await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromB64url(wrap.iv), additionalData: aad }, kek, fromB64url(wrap.wrappedKey)),
    );
    const contentKey = await crypto.subtle.importKey("raw", contentKeyBytes, "AES-GCM", false, ["decrypt"]);
    const plain = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: fromB64url(m.iv), additionalData: aad },
      contentKey,
      fromB64url(payload.ciphertext),
    );
    return fromUtf8(plain);
  } catch {
    throw new DecryptError("corrupt");
  } finally {
    wipe(contentKeyBytes);
  }
}

// Re-exported for tests that need to build keys directly.
export { ECDSA_PARAMS };
