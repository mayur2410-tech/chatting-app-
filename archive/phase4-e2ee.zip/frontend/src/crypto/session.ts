/**
 * An unlocked encryption session: the user's private keys (non-extractable, memory only), the
 * conversation's public key directory, and the user's trust decisions about their partner's key.
 * Created by unlocking (or setting up) the passphrase-encrypted envelope; destroyed on lock.
 */
import { ApiError } from "../api/client";
import {
  fetchConversationKeys,
  fetchMyKeys,
  rotateKeys as apiRotateKeys,
  setupKeys,
  updateEnvelope,
  type EnvelopeDto,
} from "../api/keys";
import {
  deriveEnvelopeKey,
  mergeContents,
  openEnvelope,
  openEnvelopeWithKey,
  sealEnvelope,
  type ContactTrust,
  type EnvelopeContents,
  type EnvelopeKey,
} from "./envelope";
import { generateKeyRecord, loadOwnKey, loadPeerKey, publicSetOf, safetyCode, type OwnKey, type PeerKey, type PublicKeySet } from "./keys";
import { DecryptError, decryptMessage, encryptMessage, senderKeyIdOf, type EncryptedPayload, type MessageContext } from "./message";

export type TrustKind = "no-conversation" | "partner-not-set-up" | "unverified" | "verified" | "changed";

export interface TrustSnapshot {
  kind: TrustKind;
  partnerKeyId: string | null;
  myKeyId: string;
  /** 12 groups of 5 digits; null until the partner has a key. */
  safetyCode: string[] | null;
}

export type DecodeResult = { ok: true; text: string } | { ok: false; reason: string };

/** Thrown when this session can no longer write the envelope (passphrase changed on another device). */
export class SessionInvalidError extends Error {}

const FAILURE_TEXT: Record<string, string> = {
  malformed: "This message is damaged and can't be decrypted.",
  corrupt: "This message is damaged and can't be decrypted.",
  unknown_sender_key: "Can't find the key this message was sent with.",
  bad_signature: "Can't verify who sent this message. It may have been tampered with.",
  not_for_this_key: "This message wasn't encrypted for your keys.",
};

function emptyTrust(): ContactTrust {
  return { pinnedKeyIds: [], verifiedKeyIds: [] };
}

export class CryptoSession {
  private ownKeys: OwnKey[];
  private directory = new Map<string, PeerKey>();
  private conversationId: string | null = null;
  private partnerId: string | null = null;
  private listeners = new Set<() => void>();
  private snapshot: TrustSnapshot;
  private destroyed = false;

  private constructor(
    readonly userId: string,
    private ek: EnvelopeKey,
    private envelopeVersion: number,
    private contents: EnvelopeContents,
    ownKeys: OwnKey[],
  ) {
    this.ownKeys = ownKeys;
    this.snapshot = { kind: "no-conversation", partnerKeyId: null, myKeyId: ownKeys[0].keyId, safetyCode: null };
  }

  // --- creation ---------------------------------------------------------------

  /** First-time setup: generate keys, seal them under the passphrase, publish the public half. */
  static async setUp(userId: string, passphrase: string): Promise<CryptoSession> {
    const record = await generateKeyRecord();
    const contents: EnvelopeContents = { v: 1, keys: [record], contacts: {} };
    const ek = await deriveEnvelopeKey(passphrase);
    const res = await setupKeys(publicSetOf(record), await sealEnvelope(contents, ek, userId));
    return new CryptoSession(userId, ek, res.envelope!.version, contents, [await loadOwnKey(record)]);
  }

  /** Unlock: derive the envelope key from the passphrase and decrypt the envelope locally. */
  static async unlock(userId: string, passphrase: string, envelope: EnvelopeDto): Promise<CryptoSession> {
    const { contents, ek } = await openEnvelope(envelope, passphrase, userId);
    const ownKeys = await Promise.all(contents.keys.map(loadOwnKey));
    return new CryptoSession(userId, ek, envelope.version, contents, ownKeys);
  }

  destroy(): void {
    this.destroyed = true;
    this.ownKeys = [];
    this.directory.clear();
    this.contents = { v: 1, keys: [], contacts: {} };
    this.listeners.clear();
  }

  // --- React subscription (useSyncExternalStore) --------------------------------

  subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  };

  getSnapshot = (): TrustSnapshot => this.snapshot;

  private async publish(): Promise<void> {
    if (this.destroyed) return;
    const partnerKey = this.partnerActiveKey();
    let kind: TrustKind;
    if (!this.conversationId || !this.partnerId) kind = "no-conversation";
    else if (!partnerKey) kind = "partner-not-set-up";
    else {
      const trust = this.contents.contacts[this.partnerId] ?? emptyTrust();
      if (!trust.pinnedKeyIds.includes(partnerKey.keyId)) kind = "changed";
      else kind = trust.verifiedKeyIds.includes(partnerKey.keyId) ? "verified" : "unverified";
    }
    const code =
      partnerKey && this.partnerId
        ? await safetyCode(
            { userId: this.userId, key: this.ownKeys[0].publicSet },
            { userId: this.partnerId, key: partnerKey.publicSet },
          )
        : null;
    if (this.destroyed) return;
    this.snapshot = { kind, partnerKeyId: partnerKey?.keyId ?? null, myKeyId: this.ownKeys[0].keyId, safetyCode: code };
    this.listeners.forEach((l) => l());
  }

  // --- directory & trust ----------------------------------------------------------

  private partnerActiveKey(): PeerKey | null {
    for (const k of this.directory.values()) if (k.userId === this.partnerId && k.active) return k;
    return null;
  }

  get myPublicKey(): PublicKeySet {
    return this.ownKeys[0].publicSet;
  }

  async attach(conversationId: string, partnerId: string): Promise<void> {
    this.conversationId = conversationId;
    this.partnerId = partnerId;
    await this.refreshDirectory();
  }

  /** Re-fetch and verify all members' public keys; pin the partner's first key (trust on first use). */
  async refreshDirectory(): Promise<void> {
    if (!this.conversationId || this.destroyed) return;
    const dtos = await fetchConversationKeys(this.conversationId);
    const next = new Map<string, PeerKey>();
    for (const dto of dtos) {
      try {
        next.set(dto.keyId, await loadPeerKey(dto)); // rejects keys whose id doesn't match their bytes
      } catch {
        // A malformed key is ignored; it can neither decrypt nor be sent to.
      }
    }
    if (this.destroyed) return;
    this.directory = next;

    // My keys were rotated on another device: pick up the new private key from the envelope.
    const myActive = dtos.find((k) => k.userId === this.userId && k.active);
    if (myActive && !this.ownKeys.some((k) => k.keyId === myActive.keyId)) await this.reloadEnvelope();

    const partnerKey = this.partnerActiveKey();
    if (partnerKey && this.partnerId) {
      const trust = this.contents.contacts[this.partnerId];
      if (!trust || trust.pinnedKeyIds.length === 0) {
        this.contents.contacts[this.partnerId] = { pinnedKeyIds: [partnerKey.keyId], verifiedKeyIds: [] };
        await this.persist();
      }
    }
    await this.publish();
  }

  async markVerified(): Promise<void> {
    const key = this.partnerActiveKey();
    if (!key || !this.partnerId) return;
    const trust = (this.contents.contacts[this.partnerId] ??= emptyTrust());
    if (!trust.pinnedKeyIds.includes(key.keyId)) trust.pinnedKeyIds.push(key.keyId);
    if (!trust.verifiedKeyIds.includes(key.keyId)) trust.verifiedKeyIds.push(key.keyId);
    await this.persist();
    await this.publish();
  }

  /** Accept the partner's new key (after a rotation or reset). It starts out unverified. */
  async acceptPartnerKey(): Promise<void> {
    const key = this.partnerActiveKey();
    if (!key || !this.partnerId) return;
    const trust = (this.contents.contacts[this.partnerId] ??= emptyTrust());
    if (!trust.pinnedKeyIds.includes(key.keyId)) trust.pinnedKeyIds.push(key.keyId);
    await this.persist();
    await this.publish();
  }

  // --- messages -------------------------------------------------------------------

  /** Encrypt for the partner's active key and our own (so our other devices can read it). */
  async encrypt(text: string, ctx: Omit<MessageContext, "senderId">): Promise<EncryptedPayload> {
    const kind = this.snapshot.kind;
    const partnerKey = this.partnerActiveKey();
    if (!partnerKey || (kind !== "verified" && kind !== "unverified")) {
      throw new Error("The partner's key is not trusted");
    }
    const me = this.ownKeys[0];
    return encryptMessage(text, { ...ctx, senderId: this.userId }, me, [partnerKey, me]);
  }

  async decrypt(message: {
    senderId: string;
    clientMessageId: string;
    ciphertext: string;
    encryptionMetadata: unknown;
  }): Promise<DecodeResult> {
    if (!this.conversationId) return { ok: false, reason: "Not ready yet." };
    const ctx: MessageContext = {
      conversationId: this.conversationId,
      senderId: message.senderId,
      clientMessageId: message.clientMessageId,
    };
    try {
      const keyId = senderKeyIdOf(message.encryptionMetadata);
      let senderKey = this.findSenderKey(message.senderId, keyId);
      if (!senderKey) {
        await this.refreshDirectory();
        senderKey = this.findSenderKey(message.senderId, keyId);
      }
      if (!senderKey) throw new DecryptError("unknown_sender_key");
      return { ok: true, text: await decryptMessage(message, ctx, senderKey, this.ownKeys) };
    } catch (err) {
      const reason = err instanceof DecryptError ? err.reason : "corrupt";
      return { ok: false, reason: FAILURE_TEXT[reason] ?? FAILURE_TEXT.corrupt };
    }
  }

  /** A key may only vouch for messages from its own owner. */
  private findSenderKey(senderId: string, keyId: string) {
    if (senderId === this.userId) return this.ownKeys.find((k) => k.keyId === keyId) ?? null;
    const peer = this.directory.get(keyId);
    return peer && peer.userId === senderId ? peer : null;
  }

  // --- passphrase & rotation --------------------------------------------------------

  async changePassphrase(newPassphrase: string): Promise<void> {
    const ek = await deriveEnvelopeKey(newPassphrase);
    const res = await updateEnvelope(await sealEnvelope(this.contents, ek, this.userId), this.envelopeVersion);
    this.ek = ek;
    this.envelopeVersion = res.envelope!.version;
  }

  /** New key set; old keys stay in the envelope so earlier messages remain readable. */
  async rotateKeys(): Promise<void> {
    const record = await generateKeyRecord();
    const contents: EnvelopeContents = { ...this.contents, keys: [record, ...this.contents.keys] };
    const res = await apiRotateKeys(publicSetOf(record), await sealEnvelope(contents, this.ek, this.userId), this.envelopeVersion);
    this.contents = contents;
    this.envelopeVersion = res.envelope!.version;
    this.ownKeys = [await loadOwnKey(record), ...this.ownKeys];
    await this.refreshDirectory();
  }

  // --- envelope persistence ----------------------------------------------------------

  private async persist(): Promise<void> {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const res = await updateEnvelope(await sealEnvelope(this.contents, this.ek, this.userId), this.envelopeVersion);
        this.envelopeVersion = res.envelope!.version;
        return;
      } catch (err) {
        if (!(err instanceof ApiError && err.status === 409) || attempt === 1) throw err;
        await this.reloadEnvelope(); // another device changed it: merge and retry
      }
    }
  }

  private async reloadEnvelope(): Promise<void> {
    const { envelope } = await fetchMyKeys();
    if (!envelope) throw new SessionInvalidError("Encryption keys were reset");
    let remote: EnvelopeContents;
    try {
      remote = await openEnvelopeWithKey(envelope, this.ek, this.userId);
    } catch {
      throw new SessionInvalidError("The passphrase was changed on another device");
    }
    this.contents = mergeContents(remote, this.contents);
    this.envelopeVersion = envelope.version;
    const known = new Set(this.ownKeys.map((k) => k.keyId));
    const added = await Promise.all(this.contents.keys.filter((k) => !known.has(k.keyId)).map(loadOwnKey));
    const all = [...added, ...this.ownKeys];
    const order = new Map(this.contents.keys.map((k, i) => [k.keyId, i]));
    this.ownKeys = all.sort((a, b) => (order.get(a.keyId) ?? 0) - (order.get(b.keyId) ?? 0));
  }
}
