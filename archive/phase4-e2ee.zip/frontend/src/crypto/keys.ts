/**
 * Long-term key sets (one per user): a P-256 ECDH key for encryption and a P-256 ECDSA key for
 * signing. Generated and used only through the Web Crypto API.
 */
import { concatBytes, fromB64url, toB64url, toHex, utf8 } from "./encoding";

export const ECDH_PARAMS: EcKeyGenParams = { name: "ECDH", namedCurve: "P-256" };
export const ECDSA_PARAMS: EcKeyGenParams = { name: "ECDSA", namedCurve: "P-256" };

/** Public half, as published to the server (base64url SubjectPublicKeyInfo). */
export interface PublicKeySet {
  keyId: string;
  encryptionKey: string;
  signingKey: string;
}

/** Private key material as stored inside the passphrase-encrypted envelope. */
export interface PrivateKeyRecord extends PublicKeySet {
  encryptionPrivateKey: string; // base64url PKCS#8
  signingPrivateKey: string; // base64url PKCS#8
  createdAt: string;
}

/** Imported, usable own key. Private CryptoKeys are non-extractable. */
export interface OwnKey {
  keyId: string;
  publicSet: PublicKeySet;
  encryptionPrivate: CryptoKey;
  signingPrivate: CryptoKey;
  encryptionPublic: CryptoKey;
  signingPublic: CryptoKey;
}

/** Imported, verified public key of any member. */
export interface PeerKey {
  keyId: string;
  userId: string;
  active: boolean;
  publicSet: PublicKeySet;
  encryptionPublic: CryptoKey;
  signingPublic: CryptoKey;
}

const KEY_ID_DOMAIN = utf8("duo-key-v1\0");

/** Must match backend app/keys/encoding.py compute_key_id. */
export async function computeKeyId(encryptionSpki: Uint8Array, signingSpki: Uint8Array): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", concatBytes(KEY_ID_DOMAIN, encryptionSpki, signingSpki));
  return toHex(digest).slice(0, 32);
}

export async function generateKeyRecord(): Promise<PrivateKeyRecord> {
  // Extractable only so the private keys can be sealed into the envelope; the working copies
  // used for messaging are re-imported as non-extractable (see loadOwnKey).
  const enc = (await crypto.subtle.generateKey(ECDH_PARAMS, true, ["deriveBits"])) as CryptoKeyPair;
  const sig = (await crypto.subtle.generateKey(ECDSA_PARAMS, true, ["sign", "verify"])) as CryptoKeyPair;
  const encSpki = new Uint8Array(await crypto.subtle.exportKey("spki", enc.publicKey));
  const sigSpki = new Uint8Array(await crypto.subtle.exportKey("spki", sig.publicKey));
  return {
    keyId: await computeKeyId(encSpki, sigSpki),
    encryptionKey: toB64url(encSpki),
    signingKey: toB64url(sigSpki),
    encryptionPrivateKey: toB64url(await crypto.subtle.exportKey("pkcs8", enc.privateKey)),
    signingPrivateKey: toB64url(await crypto.subtle.exportKey("pkcs8", sig.privateKey)),
    createdAt: new Date().toISOString(),
  };
}

export function publicSetOf(record: PublicKeySet): PublicKeySet {
  return { keyId: record.keyId, encryptionKey: record.encryptionKey, signingKey: record.signingKey };
}

async function importPublic(set: PublicKeySet) {
  const encSpki = fromB64url(set.encryptionKey);
  const sigSpki = fromB64url(set.signingKey);
  if ((await computeKeyId(encSpki, sigSpki)) !== set.keyId) throw new Error("Key id does not match public keys");
  const encryptionPublic = await crypto.subtle.importKey("spki", encSpki, ECDH_PARAMS, true, []);
  const signingPublic = await crypto.subtle.importKey("spki", sigSpki, ECDSA_PARAMS, true, ["verify"]);
  return { encryptionPublic, signingPublic };
}

export async function loadOwnKey(record: PrivateKeyRecord): Promise<OwnKey> {
  const { encryptionPublic, signingPublic } = await importPublic(record);
  const encryptionPrivate = await crypto.subtle.importKey(
    "pkcs8",
    fromB64url(record.encryptionPrivateKey),
    ECDH_PARAMS,
    false,
    ["deriveBits"],
  );
  const signingPrivate = await crypto.subtle.importKey(
    "pkcs8",
    fromB64url(record.signingPrivateKey),
    ECDSA_PARAMS,
    false,
    ["sign"],
  );
  return { keyId: record.keyId, publicSet: publicSetOf(record), encryptionPrivate, signingPrivate, encryptionPublic, signingPublic };
}

/** Imports a published key, verifying that its id really is the hash of its public keys. */
export async function loadPeerKey(set: PublicKeySet & { userId: string; active: boolean }): Promise<PeerKey> {
  const { encryptionPublic, signingPublic } = await importPublic(set);
  return { keyId: set.keyId, userId: set.userId, active: set.active, publicSet: publicSetOf(set), encryptionPublic, signingPublic };
}

// --- safety codes -------------------------------------------------------------

const SAFETY_DOMAIN = "duo-safety-v1";

async function fingerprintDigits(userId: string, key: PublicKeySet): Promise<string> {
  const digest = new Uint8Array(
    await crypto.subtle.digest(
      "SHA-256",
      concatBytes(utf8(`${SAFETY_DOMAIN}\0${userId}\0`), fromB64url(key.encryptionKey), fromB64url(key.signingKey)),
    ),
  );
  // 6 chunks of 5 bytes → 6 groups of 5 decimal digits (30 digits ≈ 100 bits per user).
  let digits = "";
  for (let i = 0; i < 30; i += 5) {
    let n = 0;
    for (let j = 0; j < 5; j++) n = n * 256 + digest[i + j];
    digits += String(n % 100_000).padStart(5, "0");
  }
  return digits;
}

/**
 * A 60-digit code that is identical on both users' devices when each sees the other's real
 * keys. Comparing it out of band detects a server substituting keys.
 */
export async function safetyCode(
  a: { userId: string; key: PublicKeySet },
  b: { userId: string; key: PublicKeySet },
): Promise<string[]> {
  const [first, second] = [a, b].sort((x, y) => (x.userId < y.userId ? -1 : x.userId > y.userId ? 1 : 0));
  const digits = (await fingerprintDigits(first.userId, first.key)) + (await fingerprintDigits(second.userId, second.key));
  return digits.match(/\d{5}/g) ?? [];
}
