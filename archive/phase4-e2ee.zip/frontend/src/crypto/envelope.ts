/**
 * The key envelope: the user's private keys and trust records, encrypted with a key derived from
 * their passphrase (PBKDF2-SHA256 → AES-256-GCM). Only the envelope's ciphertext is stored on the
 * server; the passphrase and derived key never leave the device.
 */
import { fromB64url, fromUtf8, randomBytes, toB64url, utf8, wipe } from "./encoding";
import type { PrivateKeyRecord } from "./keys";

export const PBKDF2_ITERATIONS = 600_000;
export const MIN_PBKDF2_ITERATIONS = 310_000;
const SALT_BYTES = 16;

export interface EnvelopeWire {
  kdf: "pbkdf2-sha256";
  kdfParams: { iterations: number; salt: string };
  nonce: string;
  ciphertext: string;
}

/** Per-contact trust: keys seen (pinned, trust-on-first-use) and keys confirmed by safety code. */
export interface ContactTrust {
  pinnedKeyIds: string[];
  verifiedKeyIds: string[];
}

export interface EnvelopeContents {
  v: 1;
  /** Newest first. Retired keys are kept so older messages stay readable. */
  keys: PrivateKeyRecord[];
  contacts: Record<string, ContactTrust>;
}

export class EnvelopeError extends Error {
  constructor(readonly reason: "wrong_passphrase" | "unsupported" | "corrupt") {
    super(reason);
    this.name = "EnvelopeError";
  }
}

/** Unlocked envelope key plus the salt it was derived with (needed to re-seal). */
export interface EnvelopeKey {
  key: CryptoKey;
  salt: Uint8Array;
  iterations: number;
}

function aad(userId: string): Uint8Array {
  return utf8(`duo-envelope-v1\0${userId}`);
}

export async function deriveEnvelopeKey(
  passphrase: string,
  salt: Uint8Array = randomBytes(SALT_BYTES),
  iterations = PBKDF2_ITERATIONS,
): Promise<EnvelopeKey> {
  const secret = utf8(passphrase.normalize("NFKC"));
  try {
    const base = await crypto.subtle.importKey("raw", secret, "PBKDF2", false, ["deriveKey"]);
    const key = await crypto.subtle.deriveKey(
      { name: "PBKDF2", hash: "SHA-256", salt, iterations },
      base,
      { name: "AES-GCM", length: 256 },
      false,
      ["encrypt", "decrypt"],
    );
    return { key, salt, iterations };
  } finally {
    wipe(secret);
  }
}

export async function sealEnvelope(contents: EnvelopeContents, ek: EnvelopeKey, userId: string): Promise<EnvelopeWire> {
  const nonce = randomBytes(12);
  const plaintext = utf8(JSON.stringify(contents));
  try {
    const ciphertext = await crypto.subtle.encrypt(
      { name: "AES-GCM", iv: nonce, additionalData: aad(userId) },
      ek.key,
      plaintext,
    );
    return {
      kdf: "pbkdf2-sha256",
      kdfParams: { iterations: ek.iterations, salt: toB64url(ek.salt) },
      nonce: toB64url(nonce),
      ciphertext: toB64url(ciphertext),
    };
  } finally {
    wipe(plaintext);
  }
}

/** Decrypts with an already-derived key (same salt). Throws EnvelopeError. */
export async function openEnvelopeWithKey(wire: EnvelopeWire, ek: EnvelopeKey, userId: string): Promise<EnvelopeContents> {
  let plaintext: ArrayBuffer;
  try {
    plaintext = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: fromB64url(wire.nonce), additionalData: aad(userId) },
      ek.key,
      fromB64url(wire.ciphertext),
    );
  } catch {
    throw new EnvelopeError("wrong_passphrase");
  }
  const bytes = new Uint8Array(plaintext);
  try {
    const contents = JSON.parse(fromUtf8(bytes)) as EnvelopeContents;
    if (contents.v !== 1 || !Array.isArray(contents.keys) || contents.keys.length === 0) {
      throw new EnvelopeError("unsupported");
    }
    contents.contacts ??= {};
    return contents;
  } catch (err) {
    if (err instanceof EnvelopeError) throw err;
    throw new EnvelopeError("corrupt");
  } finally {
    wipe(bytes);
  }
}

export async function openEnvelope(
  wire: EnvelopeWire,
  passphrase: string,
  userId: string,
): Promise<{ contents: EnvelopeContents; ek: EnvelopeKey }> {
  if (wire.kdf !== "pbkdf2-sha256" || wire.kdfParams.iterations < MIN_PBKDF2_ITERATIONS) {
    throw new EnvelopeError("unsupported");
  }
  const ek = await deriveEnvelopeKey(passphrase, fromB64url(wire.kdfParams.salt), wire.kdfParams.iterations);
  return { contents: await openEnvelopeWithKey(wire, ek, userId), ek };
}

/** Merge two envelope versions (e.g. after a concurrent update on another device). */
export function mergeContents(a: EnvelopeContents, b: EnvelopeContents): EnvelopeContents {
  const keys = new Map<string, PrivateKeyRecord>();
  for (const k of [...a.keys, ...b.keys]) if (!keys.has(k.keyId)) keys.set(k.keyId, k);
  const sorted = [...keys.values()].sort((x, y) => (x.createdAt < y.createdAt ? 1 : -1));
  const contacts: Record<string, ContactTrust> = {};
  for (const id of new Set([...Object.keys(a.contacts), ...Object.keys(b.contacts)])) {
    const x = a.contacts[id] ?? { pinnedKeyIds: [], verifiedKeyIds: [] };
    const y = b.contacts[id] ?? { pinnedKeyIds: [], verifiedKeyIds: [] };
    contacts[id] = {
      pinnedKeyIds: [...new Set([...x.pinnedKeyIds, ...y.pinnedKeyIds])],
      verifiedKeyIds: [...new Set([...x.verifiedKeyIds, ...y.verifiedKeyIds])],
    };
  }
  return { v: 1, keys: sorted, contacts };
}
