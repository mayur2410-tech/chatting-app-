import { useCallback, useEffect, useRef, useState } from "react";
import type { AuthUser } from "../api/auth";
import { ApiError } from "../api/client";
import { fetchMyKeys } from "../api/keys";
import { EnvelopeError } from "./envelope";
import { CryptoSession } from "./session";

export type VaultStatus = "idle" | "checking" | "needs-setup" | "locked" | "unlocked" | "error";

export const MIN_PASSPHRASE_LENGTH = 12;

export interface KeyVault {
  status: VaultStatus;
  session: CryptoSession | null;
  /** Each resolves to an error message, or null on success. */
  setUp: (passphrase: string) => Promise<string | null>;
  unlock: (passphrase: string) => Promise<string | null>;
  /** Drops all key material from memory. */
  lock: () => void;
  recheck: () => void;
}

/**
 * Tracks whether the signed-in user has encryption set up and holds the unlocked session.
 * Keys exist in memory only while unlocked; locking or signing out destroys them.
 */
export function useKeyVault(user: AuthUser | null, onAuthLost: () => void): KeyVault {
  const [status, setStatus] = useState<VaultStatus>("idle");
  const [session, setSession] = useState<CryptoSession | null>(null);
  const [checkToken, setCheckToken] = useState(0);
  const sessionRef = useRef<CryptoSession | null>(null);
  const authLostRef = useRef(onAuthLost);
  authLostRef.current = onAuthLost;
  const userId = user?.id ?? null;

  const replaceSession = useCallback((next: CryptoSession | null) => {
    sessionRef.current?.destroy();
    sessionRef.current = next;
    setSession(next);
  }, []);

  const handleError = useCallback((err: unknown): string => {
    if (err instanceof ApiError && err.status === 401) {
      authLostRef.current();
      return "Your session has ended.";
    }
    if (err instanceof EnvelopeError) {
      return err.reason === "wrong_passphrase"
        ? "Couldn't unlock. Check your passphrase."
        : "Your encrypted keys couldn't be read on this device.";
    }
    if (err instanceof ApiError && err.status === 0) return "Can't reach the server. Try again.";
    return "Something went wrong. Please try again.";
  }, []);

  useEffect(() => {
    replaceSession(null);
    if (!userId) {
      setStatus("idle");
      return;
    }
    let cancelled = false;
    setStatus("checking");
    fetchMyKeys()
      .then((keys) => {
        if (!cancelled) setStatus(keys.envelope ? "locked" : "needs-setup");
      })
      .catch((err) => {
        if (cancelled) return;
        handleError(err);
        setStatus("error");
      });
    return () => {
      cancelled = true;
    };
  }, [userId, checkToken, replaceSession, handleError]);

  // Never leave keys in memory after unmount.
  useEffect(() => () => sessionRef.current?.destroy(), []);

  const setUp = useCallback(
    async (passphrase: string) => {
      if (!userId) return "Not signed in.";
      if (passphrase.length < MIN_PASSPHRASE_LENGTH) return `Use at least ${MIN_PASSPHRASE_LENGTH} characters.`;
      try {
        replaceSession(await CryptoSession.setUp(userId, passphrase));
        setStatus("unlocked");
        return null;
      } catch (err) {
        if (err instanceof ApiError && err.status === 409) {
          setStatus("locked"); // set up meanwhile on another device
          return "Encryption was already set up on another device. Unlock with that passphrase.";
        }
        return handleError(err);
      }
    },
    [userId, replaceSession, handleError],
  );

  const unlock = useCallback(
    async (passphrase: string) => {
      if (!userId) return "Not signed in.";
      try {
        const { envelope } = await fetchMyKeys();
        if (!envelope) {
          setStatus("needs-setup");
          return "Encryption needs to be set up again.";
        }
        replaceSession(await CryptoSession.unlock(userId, passphrase, envelope));
        setStatus("unlocked");
        return null;
      } catch (err) {
        return handleError(err);
      }
    },
    [userId, replaceSession, handleError],
  );

  const lock = useCallback(() => {
    replaceSession(null);
    setStatus((s) => (s === "unlocked" ? "locked" : s));
  }, [replaceSession]);

  const recheck = useCallback(() => setCheckToken((n) => n + 1), []);

  return { status, session, setUp, unlock, lock, recheck };
}
