import { describe, expect, it } from "vitest";
import { fromB64url, toB64url } from "./encoding";
import {
  EnvelopeError,
  deriveEnvelopeKey,
  mergeContents,
  openEnvelope,
  sealEnvelope,
  type EnvelopeContents,
} from "./envelope";
import { computeKeyId, generateKeyRecord, loadOwnKey, loadPeerKey, safetyCode, type OwnKey } from "./keys";
import { DecryptError, decryptMessage, encryptMessage, type MessageContext } from "./message";

const ctx: MessageContext = {
  conversationId: "11111111-1111-4111-8111-111111111111",
  senderId: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
  clientMessageId: "22222222-2222-4222-8222-222222222222",
};

async function party(userId: string) {
  const record = await generateKeyRecord();
  const own = await loadOwnKey(record);
  const peer = await loadPeerKey({ ...record, userId, active: true });
  return { record, own, peer };
}

describe("encoding", () => {
  it("round-trips base64url", () => {
    const bytes = new Uint8Array([0, 1, 2, 250, 251, 252, 253, 254, 255]);
    expect(Array.from(fromB64url(toB64url(bytes)))).toEqual(Array.from(bytes));
    expect(toB64url(bytes)).not.toMatch(/[+/=]/);
    expect(() => fromB64url("not base64!")).toThrow();
  });
});

describe("keys", () => {
  it("key ids are bound to the public keys", async () => {
    const { record } = await party("u");
    expect(record.keyId).toMatch(/^[0-9a-f]{32}$/);
    expect(await computeKeyId(fromB64url(record.encryptionKey), fromB64url(record.signingKey))).toBe(record.keyId);
    const other = await generateKeyRecord();
    await expect(loadPeerKey({ ...record, encryptionKey: other.encryptionKey, userId: "u", active: true })).rejects.toThrow();
  });

  it("loaded private keys are non-extractable", async () => {
    const { own } = await party("u");
    expect(own.encryptionPrivate.extractable).toBe(false);
    expect(own.signingPrivate.extractable).toBe(false);
  });

  it("safety codes match on both sides and change with keys", async () => {
    const a = await party("user-a");
    const b = await party("user-b");
    const ab = await safetyCode({ userId: "user-a", key: a.record }, { userId: "user-b", key: b.record });
    const ba = await safetyCode({ userId: "user-b", key: b.record }, { userId: "user-a", key: a.record });
    expect(ab).toEqual(ba);
    expect(ab).toHaveLength(12);
    ab.forEach((g) => expect(g).toMatch(/^\d{5}$/));

    const mallory = await party("user-b");
    const swapped = await safetyCode({ userId: "user-a", key: a.record }, { userId: "user-b", key: mallory.record });
    expect(swapped).not.toEqual(ab);
  });
});

describe("duo-e2ee-v1 messages", () => {
  async function setup() {
    const alice = await party(ctx.senderId);
    const bob = await party("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb");
    const text = "Hello 👋 नमस्ते — 你好\nline two";
    const payload = await encryptMessage(text, ctx, alice.own, [alice.own, bob.peer]);
    const wire = { ciphertext: payload.ciphertext, encryptionMetadata: payload.metadata };
    return { alice, bob, text, payload, wire };
  }

  it("recipient and sender's own devices can decrypt", async () => {
    const { alice, bob, text, wire } = await setup();
    expect(await decryptMessage(wire, ctx, alice.peer, [bob.own])).toBe(text);
    expect(await decryptMessage(wire, ctx, alice.peer, [alice.own])).toBe(text);
  });

  it("ciphertext reveals nothing readable and is fresh every time", async () => {
    const { alice, bob, text, payload } = await setup();
    expect(payload.ciphertext).not.toContain("Hello");
    expect(JSON.stringify(payload.metadata)).not.toContain("Hello");
    const again = await encryptMessage(text, ctx, alice.own, [alice.own, bob.peer]);
    expect(again.ciphertext).not.toBe(payload.ciphertext);
    expect(again.metadata.iv).not.toBe(payload.metadata.iv);
    expect(payload.metadata.wraps).toHaveLength(2);
  });

  it("a third party cannot decrypt", async () => {
    const { alice, wire } = await setup();
    const eve = await party("eve");
    await expect(decryptMessage(wire, ctx, alice.peer, [eve.own])).rejects.toMatchObject({ reason: "not_for_this_key" });
  });

  it("rejects a forged sender (signature from another key)", async () => {
    const { bob, wire } = await setup();
    const mallory = await party(ctx.senderId);
    // Pretend mallory's published key is alice's: the key id check catches it...
    await expect(decryptMessage(wire, ctx, mallory.peer, [bob.own])).rejects.toMatchObject({ reason: "unknown_sender_key" });
    // ...and even with a matching id, the signature does not verify.
    const impostor = { keyId: wire.encryptionMetadata.senderKeyId, signingPublic: mallory.peer.signingPublic };
    await expect(decryptMessage(wire, ctx, impostor, [bob.own])).rejects.toMatchObject({ reason: "bad_signature" });
  });

  it.each([
    ["ciphertext", (w: any) => ({ ...w, ciphertext: toB64url(fromB64url(w.ciphertext).map((b, i) => (i === 0 ? b ^ 1 : b))) })],
    ["content iv", (w: any) => ({ ...w, encryptionMetadata: { ...w.encryptionMetadata, iv: toB64url(new Uint8Array(12)) } })],
    ["wrapped key", (w: any) => ({
      ...w,
      encryptionMetadata: {
        ...w.encryptionMetadata,
        wraps: w.encryptionMetadata.wraps.map((x: any) => ({ ...x, wrappedKey: toB64url(new Uint8Array(48)) })),
      },
    })],
    ["dropped wrap", (w: any) => ({
      ...w,
      encryptionMetadata: { ...w.encryptionMetadata, wraps: w.encryptionMetadata.wraps.slice(0, 1) },
    })],
  ])("detects tampering with the %s", async (_name, tamper) => {
    const { alice, bob, wire } = await setup();
    await expect(decryptMessage(tamper(wire), ctx, alice.peer, [bob.own])).rejects.toBeInstanceOf(DecryptError);
  });

  it.each([
    ["conversation", { conversationId: "99999999-9999-4999-8999-999999999999" }],
    ["sender", { senderId: "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb" }],
    ["client message id", { clientMessageId: "33333333-3333-4333-8333-333333333333" }],
  ])("is bound to its %s (replay into another context fails)", async (_name, change) => {
    const { alice, bob, wire } = await setup();
    await expect(decryptMessage(wire, { ...ctx, ...change }, alice.peer, [bob.own])).rejects.toMatchObject({
      reason: "bad_signature",
    });
  });

  it("rejects malformed metadata", async () => {
    const { alice, bob, wire } = await setup();
    for (const bad of [null, {}, { ...wire.encryptionMetadata, v: 2 }, { ...wire.encryptionMetadata, wraps: [] }]) {
      await expect(decryptMessage({ ...wire, encryptionMetadata: bad }, ctx, alice.peer, [bob.own])).rejects.toMatchObject({
        reason: "malformed",
      });
    }
  });

  it("older keys in the keyring still decrypt after rotation", async () => {
    const { alice, bob, text, wire } = await setup();
    const rotated: OwnKey = (await party("x")).own;
    expect(await decryptMessage(wire, ctx, alice.peer, [rotated, bob.own])).toBe(text);
  });
});

describe("key envelope", () => {
  const userId = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa";

  async function sealed(passphrase = "correct horse battery staple") {
    const record = await generateKeyRecord();
    const contents: EnvelopeContents = { v: 1, keys: [record], contacts: {} };
    const ek = await deriveEnvelopeKey(passphrase, undefined, 310_000);
    return { contents, wire: await sealEnvelope(contents, ek, userId), passphrase };
  }

  it("opens with the right passphrase only", async () => {
    const { contents, wire, passphrase } = await sealed();
    const opened = await openEnvelope(wire, passphrase, userId);
    expect(opened.contents).toEqual(contents);
    await expect(openEnvelope(wire, "wrong passphrase!!", userId)).rejects.toMatchObject({ reason: "wrong_passphrase" });
  });

  it("does not contain private keys in the clear", async () => {
    const { contents, wire } = await sealed();
    const blob = JSON.stringify(wire);
    expect(blob).not.toContain(contents.keys[0].encryptionPrivateKey.slice(0, 20));
    expect(blob).not.toContain(contents.keys[0].signingPrivateKey.slice(0, 20));
  });

  it("is bound to its user and detects tampering", async () => {
    const { wire, passphrase } = await sealed();
    await expect(openEnvelope(wire, passphrase, "someone-else")).rejects.toBeInstanceOf(EnvelopeError);
    const flipped = { ...wire, ciphertext: toB64url(fromB64url(wire.ciphertext).map((b, i) => (i === 5 ? b ^ 1 : b))) };
    await expect(openEnvelope(flipped, passphrase, userId)).rejects.toBeInstanceOf(EnvelopeError);
  });

  it("refuses a weakened KDF supplied by the server", async () => {
    const { wire, passphrase } = await sealed();
    const weak = { ...wire, kdfParams: { ...wire.kdfParams, iterations: 1000 } };
    await expect(openEnvelope(weak, passphrase, userId)).rejects.toMatchObject({ reason: "unsupported" });
  });

  it("merges concurrent versions without losing keys or trust", async () => {
    const a = await generateKeyRecord();
    const b = await generateKeyRecord();
    const merged = mergeContents(
      { v: 1, keys: [a], contacts: { p: { pinnedKeyIds: ["k1"], verifiedKeyIds: [] } } },
      { v: 1, keys: [b, a], contacts: { p: { pinnedKeyIds: ["k1", "k2"], verifiedKeyIds: ["k1"] } } },
    );
    expect(merged.keys.map((k) => k.keyId).sort()).toEqual([a.keyId, b.keyId].sort());
    expect(merged.contacts.p).toEqual({ pinnedKeyIds: ["k1", "k2"], verifiedKeyIds: ["k1"] });
  });
});
