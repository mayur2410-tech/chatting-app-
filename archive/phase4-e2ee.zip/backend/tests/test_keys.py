"""
Phase 4 server side: public key directory, encrypted key envelopes, and acceptance rules for
duo-e2ee-v1 payloads. The server never decrypts anything; it validates shapes and ownership.
Real encryption round-trips are tested in frontend/src/crypto/*.test.ts.
"""

import io
import os
import uuid

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import func, select

from app import cli
from app.config import DEV_UNENCRYPTED_VERSION, E2EE_VERSION, get_settings
from app.keys.encoding import P256_SPKI_PREFIX, b64url_encode, compute_key_id
from app.models import EncryptedKeyEnvelope, Message, UserPublicKey
from tests.conftest import FRONTEND_ORIGIN
from tests.test_messaging import Identity, conversation_id, connect, until  # noqa: F401  (fixtures below)
from tests.test_messaging import alice, bob, hub  # noqa: F401


def fake_spki() -> str:
    return b64url_encode(P256_SPKI_PREFIX + os.urandom(64))


def public_key() -> dict:
    enc, sig = fake_spki(), fake_spki()
    from app.keys.encoding import b64url_decode

    return {
        "keyId": compute_key_id(b64url_decode(enc), b64url_decode(sig)),
        "encryptionKey": enc,
        "signingKey": sig,
    }


def envelope(marker: bytes = b"x") -> dict:
    return {
        "kdf": "pbkdf2-sha256",
        "kdfParams": {"iterations": 600_000, "salt": b64url_encode(os.urandom(16))},
        "nonce": b64url_encode(os.urandom(12)),
        "ciphertext": b64url_encode(marker * 64),
    }


def setup_keys(hub: TestClient, who: Identity, pk: dict | None = None) -> dict:
    pk = pk or public_key()
    r = hub.post("/api/keys", json={"publicKey": pk, "envelope": envelope()}, headers=who.headers(csrf=True))
    assert r.status_code == 201, r.text
    return pk


def e2ee_metadata(sender_key_id: str, recipient_key_ids: list[str]) -> dict:
    return {
        "v": 1,
        "senderKeyId": sender_key_id,
        "iv": b64url_encode(os.urandom(12)),
        "ephemeralPublicKey": fake_spki(),
        "salt": b64url_encode(os.urandom(32)),
        "wraps": [
            {"recipientKeyId": k, "iv": b64url_encode(os.urandom(12)), "wrappedKey": b64url_encode(os.urandom(48))}
            for k in recipient_key_ids
        ],
        "sig": b64url_encode(os.urandom(64)),
    }


def send_e2ee(ws, sender_key_id: str, recipients: list[str], cid: str | None = None, **overrides) -> str:
    cid = cid or str(uuid.uuid4())
    ws.send_json(
        {
            "type": "message.send",
            "clientMessageId": cid,
            "ciphertext": overrides.pop("ciphertext", b64url_encode(os.urandom(40))),
            "encryptionVersion": E2EE_VERSION,
            "encryptionMetadata": overrides.pop("metadata", e2ee_metadata(sender_key_id, recipients)),
        }
    )
    return cid


# --- setup & retrieval -------------------------------------------------------


def test_setup_and_fetch_my_keys(hub, alice):
    assert hub.get("/api/keys/me", headers=alice.headers()).json() == {"publicKey": None, "envelope": None}
    pk = setup_keys(hub, alice)
    me = hub.get("/api/keys/me", headers=alice.headers()).json()
    assert me["publicKey"]["keyId"] == pk["keyId"]
    assert me["envelope"]["version"] == 1
    assert me["envelope"]["kdf"] == "pbkdf2-sha256"


def test_key_endpoints_require_auth_and_csrf(hub, alice):
    body = {"publicKey": public_key(), "envelope": envelope()}
    assert hub.get("/api/keys/me").status_code == 401
    assert hub.post("/api/keys", json=body).status_code == 401
    assert hub.post("/api/keys", json=body, headers=alice.headers()).status_code == 403  # no CSRF
    bare = {"Cookie": alice.headers()["Cookie"], "X-CSRF-Token": alice.csrf, "Origin": "https://evil.example"}
    assert hub.post("/api/keys", json=body, headers=bare).status_code == 403  # foreign origin


def test_setup_only_once(hub, alice):
    setup_keys(hub, alice)
    r = hub.post("/api/keys", json={"publicKey": public_key(), "envelope": envelope()}, headers=alice.headers(csrf=True))
    assert r.status_code == 409


@pytest.mark.parametrize(
    "mutate",
    [
        lambda pk: pk.update(keyId="0" * 32),  # key id must match the keys
        lambda pk: pk.update(encryptionKey="not base64!"),
        lambda pk: pk.update(signingKey=b64url_encode(b"\x00" * 91)),  # not a P-256 SPKI
        lambda pk: pk.update(extra="field"),
    ],
)
def test_public_key_validation(hub, alice, mutate):
    pk = public_key()
    mutate(pk)
    r = hub.post("/api/keys", json={"publicKey": pk, "envelope": envelope()}, headers=alice.headers(csrf=True))
    assert r.status_code == 422


def test_envelope_validation_rejects_weak_kdf(hub, alice):
    env = envelope()
    env["kdfParams"]["iterations"] = 1000
    r = hub.post("/api/keys", json={"publicKey": public_key(), "envelope": env}, headers=alice.headers(csrf=True))
    assert r.status_code == 422


def test_reusing_a_key_id_is_rejected(hub, alice, bob):
    pk = setup_keys(hub, alice)
    r = hub.post("/api/keys", json={"publicKey": pk, "envelope": envelope()}, headers=bob.headers(csrf=True))
    assert r.status_code == 409


# --- envelope updates & rotation ----------------------------------------------


def test_envelope_update_uses_optimistic_concurrency(hub, alice):
    setup_keys(hub, alice)
    ok = hub.put(
        "/api/keys/envelope", json={"envelope": envelope(b"y"), "expectedVersion": 1}, headers=alice.headers(csrf=True)
    )
    assert ok.status_code == 200
    assert ok.json()["envelope"]["version"] == 2
    stale = hub.put(
        "/api/keys/envelope", json={"envelope": envelope(b"z"), "expectedVersion": 1}, headers=alice.headers(csrf=True)
    )
    assert stale.status_code == 409
    assert hub.get("/api/keys/me", headers=alice.headers()).json()["envelope"]["ciphertext"] == ok.json()["envelope"]["ciphertext"]


def test_rotation_retires_old_key_and_notifies(hub, alice, bob, db):
    old = setup_keys(hub, alice)
    with connect(hub, bob) as b:
        new = public_key()
        r = hub.post(
            "/api/keys/rotate",
            json={"publicKey": new, "envelope": envelope(), "expectedVersion": 1},
            headers=alice.headers(csrf=True),
        )
        assert r.status_code == 200
        assert r.json()["publicKey"]["keyId"] == new["keyId"]
        assert until(b, "keys.changed") == {"type": "keys.changed", "userId": alice.id}

    keys = db.scalars(select(UserPublicKey).where(UserPublicKey.user_id == alice.user.id)).all()
    by_id = {k.key_id: k for k in keys}
    assert by_id[old["keyId"]].revoked_at is not None
    assert by_id[new["keyId"]].revoked_at is None


def test_setup_notifies_partner(hub, alice, bob):
    with connect(hub, bob) as b:
        setup_keys(hub, alice)
        assert until(b, "keys.changed")["userId"] == alice.id


# --- directory ---------------------------------------------------------------


def test_conversation_key_directory(hub, alice, bob):
    a_old = setup_keys(hub, alice)
    b_key = setup_keys(hub, bob)
    a_new = public_key()
    hub.post(
        "/api/keys/rotate",
        json={"publicKey": a_new, "envelope": envelope(), "expectedVersion": 1},
        headers=alice.headers(csrf=True),
    )
    cid = conversation_id(hub, bob)
    keys = hub.get(f"/api/conversations/{cid}/keys", headers=bob.headers()).json()["keys"]
    summary = {(k["userId"], k["keyId"], k["active"]) for k in keys}
    assert summary == {
        (alice.id, a_old["keyId"], False),
        (alice.id, a_new["keyId"], True),
        (bob.id, b_key["keyId"], True),
    }
    assert all("envelope" not in k and "ciphertext" not in k for k in keys)


def test_directory_requires_membership(hub, alice):
    assert hub.get(f"/api/conversations/{uuid.uuid4()}/keys", headers=alice.headers()).status_code == 404


def test_envelope_is_never_exposed_to_partner(hub, alice, bob):
    setup_keys(hub, alice)
    other = hub.get("/api/keys/me", headers=bob.headers()).json()
    assert other["envelope"] is None


# --- encrypted message acceptance -------------------------------------------


def test_e2ee_messages_are_accepted_and_relayed_opaquely(hub, alice, bob, db):
    a = setup_keys(hub, alice)
    b = setup_keys(hub, bob)
    with connect(hub, alice) as wa, connect(hub, bob) as wb:
        send_e2ee(wa, a["keyId"], [b["keyId"], a["keyId"]])
        ack = until(wa, "message.ack")["message"]
        assert ack["encryptionVersion"] == E2EE_VERSION
        received = until(wb, "message.new")["message"]
        assert received["ciphertext"] == ack["ciphertext"]
        assert received["encryptionMetadata"] == ack["encryptionMetadata"]
    assert db.scalar(select(func.count()).select_from(Message)) == 1


def test_e2ee_message_must_use_senders_current_key(hub, alice, bob, db):
    old = setup_keys(hub, alice)
    b = setup_keys(hub, bob)
    with connect(hub, alice) as wa:
        # Claiming someone else's key
        cid = send_e2ee(wa, b["keyId"], [b["keyId"]])
        err = until(wa, "error")
        assert (err["code"], err["clientMessageId"]) == ("stale_key", cid)

        # Retired key after rotation
        hub.post(
            "/api/keys/rotate",
            json={"publicKey": public_key(), "envelope": envelope(), "expectedVersion": 1},
            headers=alice.headers(csrf=True),
        )
        send_e2ee(wa, old["keyId"], [b["keyId"]])
        assert until(wa, "error")["code"] == "stale_key"
    assert db.scalar(select(func.count()).select_from(Message)) == 0


def test_retry_of_stored_message_is_acked_after_rotation(hub, alice, bob):
    a = setup_keys(hub, alice)
    b = setup_keys(hub, bob)
    with connect(hub, alice) as wa:
        cid = send_e2ee(wa, a["keyId"], [b["keyId"]])
        first = until(wa, "message.ack")
        hub.post(
            "/api/keys/rotate",
            json={"publicKey": public_key(), "envelope": envelope(), "expectedVersion": 1},
            headers=alice.headers(csrf=True),
        )
        send_e2ee(wa, a["keyId"], [b["keyId"]], cid=cid)
        assert until(wa, "message.ack")["message"]["id"] == first["message"]["id"]


@pytest.mark.parametrize(
    "overrides",
    [
        {"metadata": None},
        {"metadata": {"v": 2}},
        {"ciphertext": "not*base64"},
    ],
)
def test_malformed_e2ee_payloads_are_rejected(hub, alice, bob, db, overrides):
    a = setup_keys(hub, alice)
    with connect(hub, alice) as wa:
        send_e2ee(wa, a["keyId"], [a["keyId"]], **overrides)
        assert until(wa, "error")["code"] == "invalid_event"
    assert db.scalar(select(func.count()).select_from(Message)) == 0


def test_metadata_fields_are_shape_checked(hub, alice):
    a = setup_keys(hub, alice)
    bad = e2ee_metadata(a["keyId"], [a["keyId"]])
    bad["wraps"][0]["wrappedKey"] = b64url_encode(os.urandom(10))
    with connect(hub, alice) as wa:
        send_e2ee(wa, a["keyId"], [], metadata=bad)
        assert until(wa, "error")["code"] == "invalid_event"


def test_unencrypted_payloads_refused_when_test_mode_off(hub, alice, monkeypatch):
    monkeypatch.setattr(get_settings(), "allow_unencrypted_test_messages", False)
    info = hub.get("/api/conversations", headers=alice.headers()).json()["messaging"]
    assert info["acceptedEncryptionVersions"] == [E2EE_VERSION]
    assert info["unencryptedTestMode"] is False
    with connect(hub, alice) as wa:
        wa.send_json(
            {
                "type": "message.send",
                "clientMessageId": str(uuid.uuid4()),
                "ciphertext": "plain text",
                "encryptionVersion": DEV_UNENCRYPTED_VERSION,
            }
        )
        assert until(wa, "error")["code"] == "unsupported_version"


# --- admin recovery ------------------------------------------------------------


def test_cli_reset_keys(hub, alice, db, monkeypatch, session_factory, capsys):
    setup_keys(hub, alice)
    monkeypatch.setattr(cli, "get_sessionmaker", lambda: session_factory)
    assert cli.main(["reset-keys", "--username", "alex", "--yes"]) == 0
    assert "Keys reset" in capsys.readouterr().out
    db.expire_all()
    assert db.scalar(select(EncryptedKeyEnvelope).where(EncryptedKeyEnvelope.user_id == alice.user.id)) is None
    assert all(k.revoked_at is not None for k in db.scalars(select(UserPublicKey)))
    # The user's sessions were revoked as well
    assert hub.get("/api/keys/me", headers=alice.headers()).status_code == 401


def test_cli_reset_keys_requires_confirmation(alice, monkeypatch, session_factory):
    monkeypatch.setattr(cli, "get_sessionmaker", lambda: session_factory)
    monkeypatch.setattr("sys.stdin", io.StringIO("wrong\n"))
    assert cli.main(["reset-keys", "--username", "alex"]) == 1
