"""
Format checks for key material. The server never performs cryptography on user data; it only
verifies that uploaded values are well-formed so clients can rely on consistent shapes.
"""

import base64
import hashlib
import re
from typing import Annotated

from pydantic import AfterValidator

_B64URL = re.compile(r"^[A-Za-z0-9_-]*$")
_KEY_ID = re.compile(r"^[0-9a-f]{32}$")

# DER prefix of a SubjectPublicKeyInfo for an uncompressed P-256 point
# (id-ecPublicKey, prime256v1), followed by 0x04 || X || Y.
P256_SPKI_PREFIX = bytes.fromhex("3059301306072a8648ce3d020106082a8648ce3d030107034200") + b"\x04"
P256_SPKI_LENGTH = 91

KEY_ID_DOMAIN = b"duo-key-v1\x00"


def b64url_decode(value: str) -> bytes:
    if not _B64URL.fullmatch(value):
        raise ValueError("not base64url")
    try:
        return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))
    except (ValueError, base64.binascii.Error) as exc:  # type: ignore[attr-defined]
        raise ValueError("not base64url") from exc


def b64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode()


def compute_key_id(encryption_spki: bytes, signing_spki: bytes) -> str:
    """Must match frontend/src/crypto/keys.ts computeKeyId."""
    return hashlib.sha256(KEY_ID_DOMAIN + encryption_spki + signing_spki).hexdigest()[:32]


def _bytes(min_len: int, max_len: int | None = None):  # type: ignore[no-untyped-def]
    max_len = min_len if max_len is None else max_len

    def check(value: str) -> str:
        raw = b64url_decode(value)
        if not min_len <= len(raw) <= max_len:
            raise ValueError(f"expected {min_len}–{max_len} bytes")
        return value

    return AfterValidator(check)


def _spki(value: str) -> str:
    raw = b64url_decode(value)
    if len(raw) != P256_SPKI_LENGTH or not raw.startswith(P256_SPKI_PREFIX):
        raise ValueError("expected a P-256 SubjectPublicKeyInfo")
    return value


def _key_id(value: str) -> str:
    if not _KEY_ID.fullmatch(value):
        raise ValueError("expected a 32-character hex key id")
    return value


def b64bytes(min_len: int, max_len: int | None = None) -> type[str]:
    return Annotated[str, _bytes(min_len, max_len)]  # type: ignore[return-value]


Spki = Annotated[str, AfterValidator(_spki)]
KeyId = Annotated[str, AfterValidator(_key_id)]
