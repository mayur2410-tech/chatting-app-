import uuid
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator
from pydantic.alias_generators import to_camel

from app.auth.schemas import ApiModel
from app.keys.encoding import KeyId, Spki, b64bytes, b64url_decode, compute_key_id

MIN_PBKDF2_ITERATIONS = 310_000
MAX_ENVELOPE_CHARS = 65_536


class _In(BaseModel):
    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True, extra="forbid", frozen=True)


# --- public keys -------------------------------------------------------------


class PublicKeyIn(_In):
    key_id: KeyId
    encryption_key: Spki
    signing_key: Spki

    @model_validator(mode="after")
    def _key_id_matches(self) -> "PublicKeyIn":
        expected = compute_key_id(b64url_decode(self.encryption_key), b64url_decode(self.signing_key))
        if self.key_id != expected:
            raise ValueError("keyId does not match the public keys")
        if self.encryption_key == self.signing_key:
            raise ValueError("encryption and signing keys must differ")
        return self


class PublicKeyOut(ApiModel):
    key_id: str
    encryption_key: str
    signing_key: str
    created_at: datetime


class MemberKeyOut(PublicKeyOut):
    user_id: uuid.UUID
    active: bool


class ConversationKeysOut(ApiModel):
    keys: list[MemberKeyOut]


# --- envelopes ---------------------------------------------------------------


class KdfParams(_In):
    iterations: int = Field(ge=MIN_PBKDF2_ITERATIONS, le=10_000_000)
    salt: b64bytes(16, 64)  # type: ignore[valid-type]


class EnvelopeIn(_In):
    kdf: Literal["pbkdf2-sha256"]
    kdf_params: KdfParams
    nonce: b64bytes(12)  # type: ignore[valid-type]
    ciphertext: b64bytes(17, MAX_ENVELOPE_CHARS)  # type: ignore[valid-type]


class EnvelopeOut(ApiModel):
    version: int
    kdf: str
    kdf_params: dict
    nonce: str
    ciphertext: str
    updated_at: datetime


class MyKeysOut(ApiModel):
    public_key: PublicKeyOut | None
    envelope: EnvelopeOut | None


class SetupIn(_In):
    public_key: PublicKeyIn
    envelope: EnvelopeIn


class EnvelopeUpdateIn(_In):
    envelope: EnvelopeIn
    expected_version: int = Field(ge=1)


class RotateIn(_In):
    public_key: PublicKeyIn
    envelope: EnvelopeIn
    expected_version: int = Field(ge=1)


# --- message metadata (duo-e2ee-v1) ------------------------------------------


class WrapIn(_In):
    recipient_key_id: KeyId
    iv: b64bytes(12)  # type: ignore[valid-type]
    wrapped_key: b64bytes(48)  # type: ignore[valid-type]  # 32-byte key + 16-byte GCM tag


class E2eeMetadataIn(_In):
    """Shape check only. Signature and decryption are verified by the recipient's device."""

    v: Literal[1]
    sender_key_id: KeyId
    iv: b64bytes(12)  # type: ignore[valid-type]
    ephemeral_public_key: Spki
    salt: b64bytes(32)  # type: ignore[valid-type]
    wraps: list[WrapIn] = Field(min_length=1, max_length=4)
    sig: b64bytes(64)  # type: ignore[valid-type]  # ECDSA P-256 raw r||s
