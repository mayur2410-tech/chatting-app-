"""
Key directory endpoints. The server stores public keys and an opaque, passphrase-encrypted key
envelope per user; it never receives private keys or passphrases.
"""

import uuid

from fastapi import APIRouter, HTTPException, status
from starlette.concurrency import run_in_threadpool

from app.auth.deps import CsrfSessionDep, CurrentSessionDep, DbDep
from app.keys import service
from app.keys.schemas import (
    ConversationKeysOut,
    EnvelopeOut,
    EnvelopeUpdateIn,
    MemberKeyOut,
    MyKeysOut,
    PublicKeyOut,
    RotateIn,
    SetupIn,
)
from app.messaging import service as messaging_service
from app.messaging.connections import manager
from app.messaging.schemas import ev_keys_changed

router = APIRouter(prefix="/api", tags=["keys"])


def _my_keys(db: DbDep, user_id: uuid.UUID) -> MyKeysOut:
    key = service.active_key(db, user_id)
    envelope = service.get_envelope(db, user_id)
    return MyKeysOut(
        public_key=PublicKeyOut(
            key_id=key.key_id,
            encryption_key=key.encryption_key,
            signing_key=key.signing_key,
            created_at=key.created_at,
        )
        if key
        else None,
        envelope=EnvelopeOut(
            version=envelope.version,
            kdf=envelope.kdf,
            kdf_params=envelope.kdf_params,
            nonce=envelope.nonce,
            ciphertext=envelope.ciphertext,
            updated_at=envelope.updated_at,
        )
        if envelope
        else None,
    )


async def _notify_key_change(db: DbDep, user_id: uuid.UUID) -> None:
    conversation = await run_in_threadpool(messaging_service.get_user_conversation, db, user_id)
    if conversation is not None:
        await manager.broadcast(conversation.id, ev_keys_changed(user_id))


def _conflict(exc: service.KeyConflict) -> HTTPException:
    return HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))


@router.get("/keys/me", response_model=MyKeysOut)
def get_my_keys(current: CurrentSessionDep, db: DbDep) -> MyKeysOut:
    return _my_keys(db, current.user.id)


@router.post("/keys", response_model=MyKeysOut, status_code=status.HTTP_201_CREATED)
async def setup_keys(body: SetupIn, current: CsrfSessionDep, db: DbDep) -> MyKeysOut:
    user_id = current.user.id
    try:
        await run_in_threadpool(service.setup, db, user_id, body.public_key, body.envelope)
    except service.KeyConflict as exc:
        raise _conflict(exc) from exc
    await _notify_key_change(db, user_id)
    return await run_in_threadpool(_my_keys, db, user_id)


@router.put("/keys/envelope", response_model=MyKeysOut)
def update_envelope(body: EnvelopeUpdateIn, current: CsrfSessionDep, db: DbDep) -> MyKeysOut:
    try:
        service.update_envelope(db, current.user.id, body.envelope, body.expected_version)
    except service.KeyConflict as exc:
        raise _conflict(exc) from exc
    return _my_keys(db, current.user.id)


@router.post("/keys/rotate", response_model=MyKeysOut)
async def rotate_keys(body: RotateIn, current: CsrfSessionDep, db: DbDep) -> MyKeysOut:
    user_id = current.user.id
    try:
        await run_in_threadpool(
            service.rotate, db, user_id, body.public_key, body.envelope, body.expected_version
        )
    except service.KeyConflict as exc:
        raise _conflict(exc) from exc
    await _notify_key_change(db, user_id)
    return await run_in_threadpool(_my_keys, db, user_id)


@router.get("/conversations/{conversation_id}/keys", response_model=ConversationKeysOut)
def get_conversation_keys(conversation_id: uuid.UUID, current: CurrentSessionDep, db: DbDep) -> ConversationKeysOut:
    if not messaging_service.is_member(db, conversation_id, current.user.id):
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Not found")
    return ConversationKeysOut(
        keys=[
            MemberKeyOut(
                user_id=k.user_id,
                key_id=k.key_id,
                encryption_key=k.encryption_key,
                signing_key=k.signing_key,
                created_at=k.created_at,
                active=k.revoked_at is None,
            )
            for k in service.conversation_keys(db, conversation_id)
        ]
    )
