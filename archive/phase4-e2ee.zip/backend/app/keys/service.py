"""Public key directory and encrypted key envelope storage. No cryptography on user data here."""

import uuid

from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.auth.service import utcnow
from app.keys.schemas import EnvelopeIn, PublicKeyIn
from app.models import ConversationMember, EncryptedKeyEnvelope, UserPublicKey


class KeyConflict(Exception):
    """The request conflicts with the stored state (already set up, stale version, reused key)."""


def active_key(db: Session, user_id: uuid.UUID) -> UserPublicKey | None:
    return db.scalar(
        select(UserPublicKey).where(UserPublicKey.user_id == user_id, UserPublicKey.revoked_at.is_(None))
    )


def active_key_id(db: Session, user_id: uuid.UUID) -> str | None:
    key = active_key(db, user_id)
    return key.key_id if key else None


def get_envelope(db: Session, user_id: uuid.UUID) -> EncryptedKeyEnvelope | None:
    return db.scalar(select(EncryptedKeyEnvelope).where(EncryptedKeyEnvelope.user_id == user_id))


def _apply_envelope(row: EncryptedKeyEnvelope, envelope: EnvelopeIn) -> None:
    row.kdf = envelope.kdf
    row.kdf_params = envelope.kdf_params.model_dump(by_alias=True)
    row.nonce = envelope.nonce
    row.ciphertext = envelope.ciphertext


def _new_public_key(user_id: uuid.UUID, public_key: PublicKeyIn) -> UserPublicKey:
    return UserPublicKey(
        user_id=user_id,
        key_id=public_key.key_id,
        encryption_key=public_key.encryption_key,
        signing_key=public_key.signing_key,
    )


def setup(db: Session, user_id: uuid.UUID, public_key: PublicKeyIn, envelope: EnvelopeIn) -> None:
    """First-time key setup for a user. Fails if keys or an envelope already exist."""
    if get_envelope(db, user_id) is not None or active_key(db, user_id) is not None:
        raise KeyConflict("Encryption is already set up for this account")
    row = EncryptedKeyEnvelope(user_id=user_id, version=1)
    _apply_envelope(row, envelope)
    db.add_all([row, _new_public_key(user_id, public_key)])
    _commit(db)


def update_envelope(db: Session, user_id: uuid.UUID, envelope: EnvelopeIn, expected_version: int) -> None:
    """Replace the envelope (passphrase change, trust updates). Optimistic concurrency on `version`."""
    row = _locked_envelope(db, user_id, expected_version)
    _apply_envelope(row, envelope)
    row.version += 1
    _commit(db)


def rotate(
    db: Session, user_id: uuid.UUID, public_key: PublicKeyIn, envelope: EnvelopeIn, expected_version: int
) -> None:
    """Retire the active key and publish a new one, together with the envelope that holds both."""
    row = _locked_envelope(db, user_id, expected_version)
    db.execute(
        update(UserPublicKey)
        .where(UserPublicKey.user_id == user_id, UserPublicKey.revoked_at.is_(None))
        .values(revoked_at=utcnow())
    )
    db.add(_new_public_key(user_id, public_key))
    _apply_envelope(row, envelope)
    row.version += 1
    _commit(db)


def reset(db: Session, user_id: uuid.UUID) -> None:
    """Admin recovery for a forgotten passphrase: revoke keys and delete the envelope.
    Messages encrypted to the old keys become permanently unreadable for this user."""
    db.execute(
        update(UserPublicKey)
        .where(UserPublicKey.user_id == user_id, UserPublicKey.revoked_at.is_(None))
        .values(revoked_at=utcnow())
    )
    envelope = get_envelope(db, user_id)
    if envelope is not None:
        db.delete(envelope)
    db.commit()


def conversation_keys(db: Session, conversation_id: uuid.UUID) -> list[UserPublicKey]:
    """All keys (active and retired) of the conversation's members, oldest first."""
    return list(
        db.scalars(
            select(UserPublicKey)
            .join(ConversationMember, ConversationMember.user_id == UserPublicKey.user_id)
            .where(ConversationMember.conversation_id == conversation_id)
            .order_by(UserPublicKey.created_at)
        )
    )


def _locked_envelope(db: Session, user_id: uuid.UUID, expected_version: int) -> EncryptedKeyEnvelope:
    row = db.scalar(
        select(EncryptedKeyEnvelope).where(EncryptedKeyEnvelope.user_id == user_id).with_for_update()
    )
    if row is None:
        raise KeyConflict("Encryption is not set up for this account")
    if row.version != expected_version:
        raise KeyConflict("Keys were changed on another device")
    return row


def _commit(db: Session) -> None:
    try:
        db.commit()
    except IntegrityError as exc:  # e.g. a key id that already exists
        db.rollback()
        raise KeyConflict("Key already exists") from exc
