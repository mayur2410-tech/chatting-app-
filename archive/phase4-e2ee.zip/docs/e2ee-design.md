# Duo end-to-end encryption (duo-e2ee-v1)

Status: implemented in Phase 4. **Prototype-grade:** built only from standard, widely reviewed
primitives via the browser's Web Crypto API, but the *composition* is custom and has not been
independently audited. Do not describe it as audited or production-grade E2EE.

Code: `frontend/src/crypto/` (all cryptography), `backend/app/keys/` (storage + format checks only).

## Goals and non-goals

| Provides | Does **not** provide |
| --- | --- |
| Message confidentiality against the server, database, backups and network | Forward secrecy — a compromised private key decrypts all past and future messages |
| Integrity: any modification of a message or its metadata is detected | Post-compromise security (no ratcheting) |
| Sender authentication (ECDSA signature by the sender's key) | Deniability — signatures prove authorship |
| Binding to conversation, sender, sender key and message id (no cut-and-paste or replay into another context) | Metadata privacy (see below) |
| Detection of server key substitution, **once safety codes have been compared** | Protection on a compromised device, browser, or extension |
| Encrypted key backup + recovery on a new device with the passphrase | Protection of a weak passphrase against offline guessing by someone holding the database |

## Keys

Each **user** has one active key set (shared by all their devices via the envelope):

- `E`: ECDH P-256 (encryption), `S`: ECDSA P-256 (signing), generated with `crypto.subtle.generateKey`.
- `keyId` = first 16 bytes (hex) of `SHA-256("duo-key-v1\0" ‖ SPKI(E) ‖ SPKI(S))`. Recomputed by the
  server on upload and by every client on download, so a key id cannot point at different key bytes.
- Public halves (SPKI, base64url) are published to `user_public_keys`. Retired keys are kept (revoked)
  so older messages remain verifiable.
- In memory, private keys are re-imported as **non-extractable** `CryptoKey`s and exist only while the
  app is unlocked. Lock, sign-out and session expiry destroy the session object.

### Key envelope (backup and multi-device)

```
envelope key  = PBKDF2-SHA256(passphrase.normalize("NFKC"), salt = 16 random bytes, 600 000 iterations) → AES-256-GCM
envelope      = AES-256-GCM(envelope key, nonce = 12 random bytes,
                            plaintext = {v:1, keys:[private key records…], contacts:{userId: {pinnedKeyIds, verifiedKeyIds}}},
                            AAD = "duo-envelope-v1\0" ‖ userId)
```

- Stored in `encrypted_key_envelopes` with a `version` for optimistic concurrency between devices
  (conflicts are merged client-side: union of keys and trust records).
- The passphrase and envelope key never leave the device. A wrong passphrase simply fails the GCM tag check.
- Clients refuse envelopes with fewer than 310 000 iterations, so a malicious server cannot weaken the KDF.
- PBKDF2 is used because Web Crypto has no memory-hard KDF (Argon2/scrypt). The passphrase must therefore
  be strong: minimum 12 characters is enforced; several unrelated words are recommended.

## Message format

`encryptionVersion = "duo-e2ee-v1"`; `ciphertext` and `encryptionMetadata` carry:

```
ctx  = (conversationId, senderId, clientMessageId)
AAD  = JSON["duo-e2ee-v1", conversationId, senderId, senderKeyId, clientMessageId]

K           ← 32 random bytes                                   (per-message content key)
ciphertext  = AES-256-GCM(K, iv = 12 random bytes, text, AAD)
eph         ← fresh ECDH P-256 key pair                         (per message)
salt        ← 32 random bytes
for R in {partner's active key, sender's own active key}:
    KEK_R     = HKDF-SHA256(ECDH(eph.private, R.E), salt, info = "duo-e2ee-v1/wrap\0" ‖ R.keyId) → AES-256-GCM
    wrap_R    = AES-256-GCM(KEK_R, iv_R = 12 random bytes, K, AAD)
sig = ECDSA-P256-SHA256(S_sender, JSON[version, conversationId, senderId, senderKeyId, clientMessageId,
                                      v, iv, ciphertext, ephemeralPublicKey, salt, wraps])
metadata = {v:1, senderKeyId, iv, ephemeralPublicKey, salt, wraps:[{recipientKeyId, iv, wrappedKey}], sig}
```

Wrapping for the sender's own key lets the user's other devices read their sent messages.

**Decryption** (recipient): look up `senderKeyId` in the verified directory and require that the key
belongs to the message's `senderId` (assigned by the server from the session) → verify the signature
→ find a wrap for one of the recipient's keys (current or retired) → ECDH + HKDF → unwrap `K` → decrypt.
Any failure is shown in the bubble ("can't verify who sent this", "damaged", …); nothing is shown as
plaintext unless every check passes.

**Server checks** (shape only): base64url fields with the exact byte lengths, a P-256 SPKI ephemeral
key, 1–4 wraps, and `senderKeyId` equal to the sender's *current* key (retries of already-stored
messages are exempt). The server cannot decrypt or verify signatures — it has no reason to.

## Trust: safety codes and key changes

- **Trust on first use:** the first key seen for the partner is pinned inside the user's own envelope
  (encrypted and authenticated, so the server cannot alter the pin).
- **Safety code:** for each user, `SHA-256("duo-safety-v1\0" ‖ userId ‖ "\0" ‖ SPKI(E) ‖ SPKI(S))` →
  30 digits; the two halves ordered by user id give a 60-digit code (12 groups of 5) that is identical on
  both devices. Comparing it out of band (in person or on a call) detects a server that substituted keys.
  The user then marks the partner as **verified** (also stored in the envelope).
- **Key change:** if the partner's active key is not pinned, the UI shows *Safety code changed* and
  **sending is blocked** until the user verifies the new code or explicitly accepts the key (unverified).

## Rotation, devices and recovery

| Situation | What happens |
| --- | --- |
| New phone / browser | Sign in, enter the passphrase: the envelope is downloaded and decrypted locally. Full history readable. |
| Rotate keys (Security sheet) | New key set; old keys stay in the envelope (old messages readable); old public key is revoked; the partner sees *safety code changed*. |
| Change passphrase | Envelope re-encrypted under a new salt/key. Other devices' open sessions stop being able to save trust changes and are asked to unlock again. |
| Lost device | Lock-screen protects keys in memory only while unlocked; sign the device out (`app.cli revoke-sessions`). Consider rotating keys and changing the passphrase. |
| **Forgotten passphrase** | Unrecoverable by design. An admin runs `python -m app.cli reset-keys --username …`: keys revoked, envelope deleted, sessions revoked. The user sets up new keys; **all earlier messages become unreadable to them**, and the partner sees a key change. |
| Server/database stolen | Messages remain encrypted. The attacker can attempt offline passphrase guessing against envelopes (600k PBKDF2 iterations per guess) — strong passphrases matter. |

## Metadata visible to the server

Account names and display names; who sent each message and when; ciphertext size (≈ text length);
delivery and deletion times; key ids and key publication/rotation times; connection times and
frequency; the client's IP address at the network level (not stored by the app). Message text, the
passphrase and private keys are never visible to the server.

## Browser and device limitations

- JavaScript cannot guarantee secrets are erased from memory; the app drops references and zeroes the
  byte buffers it creates, but the browser/OS may retain copies (and swap them to disk).
- Code is delivered by the server on each load: a compromised server could ship malicious JavaScript
  that captures passphrases. Strict CSP, no third-party scripts, and HTTPS (Phase 6) reduce — but
  cannot remove — this inherent web-app risk.
- Browser extensions with access to the page can read decrypted messages and typed passphrases.
- Screenshots, screen sharing, the OS app switcher and other people looking at the screen are out of scope.

## Phase 3 test messages

`dev-unencrypted-v0` payloads (plain text) are still *readable* for old test data and marked "Not
encrypted". The server refuses to *store* them unless `ALLOW_UNENCRYPTED_TEST_MESSAGES=true`, which is now
`false` by default and rejected at startup in production.

## Tests

- `frontend/src/crypto/crypto.test.ts` (22): round-trip, third-party decryption fails, forged signature,
  tampering (ciphertext, IV, wrapped key, removed wrap), context binding (conversation, sender, message id),
  malformed metadata, rotation, envelope (wrong passphrase, tamper, user binding, weakened KDF, merge),
  safety-code symmetry.
- `frontend/src/e2e/twoUsers.e2e.test.ts` (opt-in): full two-user flow against a running server.
- `backend/tests/test_keys.py` (25): key/envelope APIs, CSRF/auth, validation, concurrency, rotation,
  directory, payload acceptance rules, admin reset.
